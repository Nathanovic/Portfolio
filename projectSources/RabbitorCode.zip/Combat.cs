﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//this class contains basic combat implementations
public class Combat : MonoBehaviour {
	protected Character characterScript;

	public int attackDamage = 1;
	public int health = 2;

	protected float hittedTargetTime;
	[SerializeField]private float hitCountdown = 2f;
	public bool canHitTarget{
		get{ 
			return ((Time.time - hitCountdown) > hittedTargetTime) ? true : false;
		}  
	}

	private float hittedMeTime;
	private float hitMeCountdown = 1f;
	protected bool canHitMe{
		get{ 
			return ((Time.time - hittedMeTime) > hitMeCountdown) ? true : false;
		}
	}

	void Start(){
		characterScript = GetComponent <Character> ();
		characterScript.combatDelegate = CombatUpdate;
		Init ();
	}
	protected virtual void Init(){}

	protected virtual void CombatUpdate(){}

	//this function is called from another character that tries to hit me
	public void ApplyDamage(int dmg){
		if (canHitMe) {
			hittedMeTime = Time.time;
			health -= dmg;
			if (health <= 0) {
				Die ();
			}
			ApplyDamageImpact (dmg);
		}
	}

	void Die(){
		characterScript.isInControl = false;
		transform.tag = "Untagged";
		InitDie ();
		Invoke ("DestroyMe", 1f);
	}
	protected virtual void InitDie(){
		StartCoroutine (FadeMeOut ());		
	}

	//if I'm killed: fade me out:
	IEnumerator FadeMeOut(){
		SpriteRenderer myRenderer = GetComponentInChildren<SpriteRenderer> ();
		Color renderColor = myRenderer.color;
		float t = 0f;
		while(t < 1f){
			t += Time.deltaTime;
			float a = 1f - t;
			renderColor.a = a;
			myRenderer.color = renderColor;
			yield return 0;
		}
	}

	void DestroyMe(){
		Destroy (gameObject);
	}
	protected virtual void ApplyDamageImpact(int dmg){
		GameManager.Instance.ImpactFreeze (0.0015f);
	}
}
