﻿using System.Collections;
using UnityEngine;

//the basics for every character in the game
//more components can be added to increase functionality
//player & AI both have seperate classes that inherit from this class
[RequireComponent(typeof(Combat))]
public class Character : MonoBehaviour {	//movement & physics & calling other scripts to do their job
	[HideInInspector]public Rigidbody2D rb;

	public float grip = 3.6f;
	public float movementSpeed = 3.5f;// = max x velocity, wordt gebruikt voor chargeberekening
	public float slideMultiplier = 0.85f;
	[HideInInspector]public Vector2 lookDir = new Vector2(1,0);//used by characterRaycaster
	public float moveInstruction;

	public RaycastInfo raycastInfo = new RaycastInfo();//edited by characterRaycaster

	public delegate void DoDelegate();
	public DoDelegate raycastCheckDelegate;//subscribed to by CharacterRaycaster
	public DoDelegate animateDelegate;//subscribed to by CharacterAnimation
	public DoDelegate jumpDelegate;//subscribed to by platformercharactercontroller, subscribed to by playeranimation
	public DoDelegate chargeDelegate;//subscribed to by PlayerCharge, overrides movementSpeed
	public DoDelegate combatDelegate;//subscribed to by Combat
	public bool charge;//set by PlayerCharge, remains false if this component is not on this character

	public delegate bool ValidLookDir ();
	public ValidLookDir validLookDirDelegate;//subscribed to by playerRaycaster
	public DoDelegate changeLookDirDelegate;//subscribed to by LanceCombat for changing the lance hinge joint limits

	[HideInInspector]public bool isInControl;//set to false on die by Combat

	void Start(){
		isInControl = true;
		changeLookDirDelegate += ChangeLookDir;
		rb = GetComponent <Rigidbody2D> ();
		Init ();
	}
	protected virtual void Init(){}

	void Update () {
		if (isInControl) {
			//for the player: get Input; for the AI: get movement based on a target position
			GetMovement ();
			//make sure the character looks in the right direction:
			LookAtMoveDir ();

			//raycasting can help to prevent collision and walk-animations where we don't want them
			if(raycastCheckDelegate != null)
				raycastCheckDelegate ();

			//for the player, when he is charging:
			if (chargeDelegate != null)
				chargeDelegate ();//can override moveInstruction	

			//any combat stuff:
			combatDelegate ();    //AI combat can override moveInstruction

			//animate the character if he has a CharacterAnimation script:
			if(animateDelegate != null)
				animateDelegate ();

			//only the player can jump
			if(jumpDelegate != null)
				jumpDelegate ();
		}
	}
	void FixedUpdate(){//Move V2
		if (raycastInfo.hitFront || !isInControl)
			moveInstruction = 0f;
		
		rb.AddForce (Vector2.right * grip * moveInstruction);

		Vector3 myVel = rb.velocity;
		if (moveInstruction == 0f)//afremmen
			myVel.x *= slideMultiplier;
		else{//maximale snelheid wordt 'speed'
			float x = Mathf.Abs (myVel.x) / (Mathf.Abs(moveInstruction) * movementSpeed);
			if (x > 1f)
				myVel.x /= x;
		}if (charge)
			myVel.y = 0f;
		rb.velocity = myVel;
	}
		
	void LookAtMoveDir(){
		if(!charge && ((lookDir == Vector2.right && moveInstruction < 0f) || (lookDir == Vector2.left && moveInstruction > 0f))){
			if (validLookDirDelegate != null) {
				if (validLookDirDelegate ())
					changeLookDirDelegate ();
				else
					moveInstruction = 0f;
			}else
				changeLookDirDelegate ();				
		}
	}

	protected virtual void GetMovement(){} 

	void ChangeLookDir(){
		Vector3 newLocalScale = transform.localScale;
		newLocalScale.x *= -1f;
		lookDir = new Vector2 (newLocalScale.x,0);
		transform.localScale = newLocalScale;
	}
}