Hoe is het opgebouwd:
-De Character class wordt door alle 'levende' characters in de game gebruikt
-De PlayerController class inherit van de Character class
-De Combat class geeft een basis implementatie van de combat van een character
