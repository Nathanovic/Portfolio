﻿using System.Collections;
using UnityEngine;

//player-character implementation with additional:
//-receive input
//-jump behaviour
[RequireComponent(typeof(PlayerCharge))]
public class PlayerController: Character {	
	private Raycaster raycastScript;
	private Animator anim;

	[Header("Jump values:")]
	[SerializeField]private float jumpVelocity = 5f;
	private const float standardGravityScale = 2.4f;
	private const float fallGravityScale = 3.2f;

	private float startJumpingTime; 
	[SerializeField]private float pressJumpTimeLimit = 0.7f;

	private bool validJumpButtonDown;
	[HideInInspector]public int jumpState = -1;//is also evaluated by the PlayerCharge script
	[SerializeField]private float jumpTurningPointYVel = 0.3f;
	[SerializeField]private float touchDownGroundDist = 0.2f;

	protected override void Init(){
		raycastScript = GetComponent <Raycaster> ();
		anim = transform.GetChild (0).GetComponent <Animator> ();

		SetGravityScale ();

		jumpDelegate += CreateJump;
	}

	//Get player input:
	protected override void GetMovement(){
		float moveInputSpeed = Input.GetAxisRaw ("Horizontal");
		if (moveInputSpeed > 0)
			moveInputSpeed = 1f;
		else if (moveInputSpeed < 0)
			moveInputSpeed = -1f;
		moveInstruction = moveInputSpeed;
	}

	//Try to start jumping:
	public void CreateJump(){
		if (!charge) {
			if (rb.velocity.y >= -0.01f)
				JumpBehaviour ();
			if(rb.velocity.y <= 0.01f)
				FallBehaviour ();
		} 

		anim.SetInteger ("jumpState", jumpState);
	}

	private void JumpBehaviour(){
		if (Input.GetButtonDown ("Jump") && jumpState == -1 && raycastInfo.hitGround) {
			validJumpButtonDown = true;
			jumpState = 1;//sla prepare anim over
			startJumpingTime = Time.time;	
			Ascent ();
		} else if (jumpState == 1 && rb.velocity.y < jumpTurningPointYVel && !raycastInfo.hitGround)
			jumpState = 2;

		if (validJumpButtonDown && !Input.GetButtonUp ("Jump") && (Time.time - startJumpingTime) < pressJumpTimeLimit) {
			if (jumpState >= 0)
				Ascent ();
		} else
			validJumpButtonDown = false;
	}
	private void Ascent(){
		Vector3 myVelocity = rb.velocity;
		myVelocity.y = jumpVelocity;
		rb.velocity = myVelocity;
	}

	private void FallBehaviour(){
		if(rb.velocity.y < 0f){
			SetGravityScale (fallGravityScale);
			if (rb.velocity.y < -jumpTurningPointYVel && jumpState < 3)
				jumpState = 3;
		}
		if (jumpState >= 2 && jumpState != 4 && raycastScript.TouchDownGround (touchDownGroundDist)) 
			jumpState = 4;
		if (jumpState == 4 && raycastInfo.hitGround)
			StopJump ();
	}
	private void StopJump(){
		jumpState = -1;
		SetGravityScale ();
	}

	public void SetGravityScale(float newScale = standardGravityScale){
		rb.gravityScale = newScale;
	}
}
