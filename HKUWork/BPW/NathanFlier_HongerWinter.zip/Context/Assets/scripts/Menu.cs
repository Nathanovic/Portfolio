﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour {

	private CanvasGroup currentPanel;

	public CanvasGroup mainMenuPanel;
	public CanvasGroup hostingPanel;
	public CanvasGroup connectionPanel;
	public CanvasGroup lobbyPanel;

	public float fadeOutTime = 1f;
	public float fadeInTime = 0.7f;
	public float fadeExtraWaitTime = 0.1f;

	private Text joinedPlayersText;
	private List<string> joinedPlayers;
	private GameObject startButton;

	void Start(){
		currentPanel = mainMenuPanel;
		joinedPlayersText = GameObject.Find ("JoinedPlayers").GetComponent <Text> ();
		joinedPlayers = new List<string>();
		startButton = lobbyPanel.transform.FindChild ("Start").gameObject;
	}

	public void ButtonCancel(){
		StartCoroutine(FadeOutPanel ());
		StartCoroutine(FadeInPanel (mainMenuPanel));
	}

	public void EnterLobby(bool isHost, string errorText = ""){
		Text lobbyTitle = lobbyPanel.transform.FindChild ("Title").GetComponent <Text> ();		
		if (isHost) {
			lobbyTitle.text = "Server is waiting";
			startButton.SetActive (true);
		}else {
			lobbyTitle.text = "Wachten op de anderen...";
			startButton.SetActive (false);
		}
		if (errorText != "") {
			lobbyTitle.text = errorText;
			lobbyTitle.fontSize = 50;
		} else {
			lobbyTitle.fontSize = 100;
		}

		StartCoroutine (FadeOutPanel ());
		StartCoroutine (FadeInPanel (lobbyPanel));	
	}

	public void PlayerEnteredLobby(string familyName){
		joinedPlayers.Add (familyName);
		string joinedPlayersString = "";
		foreach(string fName in joinedPlayers){
			joinedPlayersString += "- " + fName + "\n";
		}
		joinedPlayersText.text = joinedPlayersString;
	}

	public void LeaveLobby(){
		joinedPlayers = new List<string>();		
	}

	IEnumerator FadeInPanel(CanvasGroup cvg){
		yield return new WaitForSeconds (fadeOutTime + fadeExtraWaitTime);

		float t = 0;
		while(t < 1){
			t += Time.deltaTime / fadeInTime;
			cvg.alpha = t;
			yield return 0;
		}
		cvg.blocksRaycasts = true;
		cvg.interactable = true;

		currentPanel = cvg;
	}
	IEnumerator FadeOutPanel(){
		currentPanel.interactable = false;
		float t = 0;
		while(t < 1){
			t += Time.deltaTime / fadeOutTime;
			currentPanel.alpha = 1-t;
			yield return 0;
		}
		currentPanel.blocksRaycasts = false;
	}
}
