﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Net;
using System;
using System.IO;

public class Server : ConnectionBase {
	public List<ServerClient> clients;
	private List<ServerClient> disconnectList;

	private TcpListener server;
	private bool serverStarted;

	public void Init(){
		DontDestroyOnLoad (gameObject);
		clients = new List<ServerClient> ();
		disconnectList = new List<ServerClient> ();

		try{
			server = new TcpListener(IPAddress.Parse (GameManager.instance.hostAddress), GameManager.instance.port);
			server.Start ();
			serverStarted = true;

			StartListening ();
		}
		catch(Exception e){
			Debug.Log ("socket error: " + e.Message);
			serverStarted = false;
		}
	}

	void Update () {
		if (!serverStarted)
			return;

		foreach(ServerClient c in clients){
			//is the client still connected?
			if (!IsConnected (c.tcp)) {
				c.tcp.Close ();
				disconnectList.Add (c);
				continue;
			} else {
				NetworkStream s = c.tcp.GetStream ();
				if(s.DataAvailable){
					StreamReader reader = new StreamReader (s, true);
					string data = reader.ReadLine ();

					if (data != null)
						OnIncomingData (c, data);
				}
			}
		}

		for(int i = 0; i < disconnectList.Count - 1; i ++){
			//tell our player somebody has disconnected
			clients.Remove (disconnectList[i]);
			disconnectList.RemoveAt (i);
		}
	}
	
	private void StartListening(){
		if (!gameStarted)
			server.BeginAcceptTcpClient (AcceptTcpClient,server);
	}
	private void AcceptTcpClient(IAsyncResult ar){
		TcpListener listener = (TcpListener)ar.AsyncState;
		ServerClient sc = new ServerClient (listener.EndAcceptTcpClient (ar));

		string allUsers = "";
		foreach (ServerClient c in clients) {
			allUsers += "|" + c.clientName;
		}

		clients.Add (sc);

		StartListening ();

		Broadcast ("SWHO" + allUsers, sc);
	}

	private bool IsConnected(TcpClient c){
		try{
			if(c != null && c.Client != null && c.Client.Connected){
				if(c.Client.Poll (0,SelectMode.SelectRead))
					return !(c.Client.Receive (new byte[1], SocketFlags.Peek) == 0);
				
				return true;
			}else
				return false;
		}
		catch{
			return false;
		}
	}

	//server send to all clients
	public void BroadcastAll(string data){
		Broadcast (data,clients);
	}
	//server send to multiple clients
	private void Broadcast(string data, List<ServerClient> cl){
		foreach(ServerClient sc in cl){
			try{
				StreamWriter writer = new StreamWriter(sc.tcp.GetStream ());
				writer.WriteLine (data);
				writer.Flush ();
			}	
			catch(Exception e){
				Debug.Log ("Write broadcast error: " + e.Message);
			}
		}
	}
	//server send to one client
	private void Broadcast(string data, ServerClient c){
		try{
			StreamWriter writer = new StreamWriter(c.tcp.GetStream ());
			writer.WriteLine (data);
			writer.Flush ();
		}	
		catch(Exception e){
			Debug.Log ("Write broadcast error: " + e.Message);
		}
	}
	//server read & respond
	private void OnIncomingData(ServerClient c, string data){
		string[] splittedData = data.Split ('|');
		switch(splittedData[0]){
		case "CWHO":
			c.clientName = splittedData [1];
			BroadcastAll ("SCNN|" + c.clientName);

			int clientID = 0;
			foreach (ServerClient sc in clients) {
				if(sc.clientName == c.clientName){
					clientID ++;
				}
			}
			Broadcast ("SGID|" + clientID.ToString (), c);//give id
			break;
		case "CID":
			c.familyID = splittedData [1];//werkt voor geen klap
			break;
		case "CSGR":
			BroadcastAll ("SSG");//StartGame
			break;
		case "BNT":
			BroadcastAll ("SNT");//BeamerNextTurn
			break;
		case "BSNT":
			BroadcastAll ("SSNT");
			break;
		case "CT"://zou niet broadcastall mogen zijn....
			data = data.Replace ("CT","ST");
			BroadcastAll (data);//Trade
			break;
		case "CATO"://zou niet broadcastall mogen zijn....
			data = data.Replace ("CATO", "SATO");
			BroadcastAll (data);//accepted trade offer
			break;
		}
	}

	void OnApplicationQuit(){
		server.Stop ();
	}
	void OnDestroy(){
		server.Stop ();
	}
}

[System.Serializable]
public class ServerClient{
	public string clientName;
	public string familyID;
	public TcpClient tcp;

	public ServerClient(TcpClient tcp){
		this.tcp = tcp;
	}
}