﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ConnectionBase : MonoBehaviour {

	public bool gameStarted;

	// Use this for initialization
	void Start () {
		SceneManager.sceneLoaded += OnLevelFinishedLoading;
	}
	void OnLevelFinishedLoading(Scene scene, LoadSceneMode mode){
		gameStarted = true;
		ClientLevelLoaded ();
	}
	public virtual void ClientLevelLoaded(){}

	private void OnDisable(){
		SceneManager.sceneLoaded -= OnLevelFinishedLoading;
	}
}
