﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.IO;
using System;

public class Client : ConnectionBase {
	private bool socketReady;
	private TcpClient socket;
	private NetworkStream stream;
	private StreamWriter writer;
	private StreamReader reader;

	public string familyName;
	public ClientRole clientRole;
	public int clientID;//1 of 2
	private List<GameClient> players = new List<GameClient>();

	private Menu menuScript;
	private PlayerData playerScript;
	private Trade tradeScript;
	private Infoscreen infoscreenScript;
	private EventManager eventScript;

	public TradeFamilyID clientTradeID;

	void Awake(){
		DontDestroyOnLoad (gameObject);
		clientTradeID = TradeFamilyID.FamilyIDNotFound;
		menuScript = GameObject.Find ("MenuManager").GetComponent <Menu> ();
	}
	public override void ClientLevelLoaded(){
		if (clientRole == ClientRole.client) {
			GameObject clientGameObj = GameObject.Find ("Game");
			playerScript = clientGameObj.GetComponent <PlayerData> ();
			playerScript.Init (familyName, clientID);
			tradeScript = clientGameObj.GetComponent <Trade> ();
			tradeScript.Init (this);
			eventScript = clientGameObj.GetComponent <EventManager> ();
		} else {
			infoscreenScript = GameObject.Find ("InfoManager").GetComponent <Infoscreen> ();
		}
	}

	public bool ConnectToServer(string host, int port, out string errorMessage){
		errorMessage = "";
		if (socketReady)
			return false;

		try{
			socket = new TcpClient(host, port);
			stream = socket.GetStream ();
			writer = new StreamWriter(stream);
			reader = new StreamReader(stream);

			socketReady = true;
		}
		catch(Exception e){
			errorMessage = "Socket error: " + e.Message;
			Debug.Log (errorMessage);
		}

		return socketReady;
	}

	private void Update(){
		if (socketReady) {
			if(stream.DataAvailable){
				string data = reader.ReadLine ();
				if(data != null)
					OnIncomingData (data);
			}
		}
	}

	//read messages from the server
	private void OnIncomingData(string data){
		string[] splittedData = data.Split ('|');
		switch(splittedData[0]){
		case "SWHO":
			for (int i = 1; i < splittedData.Length; i++) {
				AddGameClient (splittedData [i]);
			}
			SendData ("CWHO|" + familyName);
			break;
		case "SGID":
			clientID = int.Parse (splittedData [1]);
			break;
		case "SCNN":
			AddGameClient (splittedData [1]);
			break;
		case "SSG":
			GameManager.instance.StartGame (clientRole);
			break;
		case "SNT":
			if (clientRole == ClientRole.client)
				playerScript.NextTurn ();
			else
				infoscreenScript.NextTurn ();
			break;
		case "SSNT":
			if (clientRole == ClientRole.client)
				eventScript.StartEvent ();
			else
				infoscreenScript.StartNextTurn ();
			break;
		case "ST":
			if (splittedData [4] == clientTradeID.ToString ()) {
				string tradeData = data.Remove (0, 3);
				tradeScript.ShowTradeOffer (tradeData);
			}
			break;
		case "SATO":
			if (splittedData [1] == clientTradeID.ToString ()) {
				int removeAmount = 6 + splittedData [1].Length;
				string tradeData = data.Remove (0, removeAmount);
				tradeScript.TradeOfferAccepted (tradeData);
			}
			break;
		}
	}
	//send message to server
	public void SendData(string data){
		if(!socketReady)
			return;

		writer.WriteLine (data);
		writer.Flush ();
	}

	private void AddGameClient(string famName){
		GameClient gc = new GameClient ();
		gc.familyName = famName;
		if(famName == "Host"){
			gc.isHost = true;
		}
		players.Add (gc);

		menuScript.PlayerEnteredLobby (famName);
	}

	private void OnApplicationQuit(){
		CloseSocket ();
	}
	private void OnDestroy(){
		CloseSocket ();
	}
	private void CloseSocket(){
		if (!socketReady)
			return;

		reader.Close ();
		socket.Close ();
		writer.Close ();
		socketReady = false;
	}
}

public class GameClient{
	public string familyName;
	public bool isHost;
}

public enum ClientRole{
	client,
	beamerPC,
	host
}