﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Infoscreen : MonoBehaviour {
	public int currentTurn = 1;
	public Text currentTurnText;
	private Client clientScript;

	private Image bgImage;
	public GameObject[] infoObjs;
	public Image mobileOverlayImg;
	private Color overlayColor;

	private AudioSource mySource;

	private bool playOnMobile = false;
	private float minClickDelay = 1f;
	private float lastClickTime;

	void Start () {
		mySource = GetComponent <AudioSource> ();
		mySource.Play ();

		overlayColor = mobileOverlayImg.color;
		overlayColor.a = 0.01f;
		mobileOverlayImg.enabled = false;

		clientScript = FindObjectOfType<Client> ();
	}
		
	public void ButtonContinue(){
		if ((Time.time - lastClickTime) > minClickDelay) {
			lastClickTime = Time.time;
			if (playOnMobile){
				mobileOverlayImg.enabled = false;
				clientScript.SendData ("BNT");//beamer Next Turn
			}
			else
				clientScript.SendData ("BSNT");//beamer start next turn
		} 
	}
	public void NextTurn(){
		playOnMobile = false;

		currentTurn++;
		currentTurnText.text = "Beurt " + currentTurn;

		if(currentTurn > 1)
			infoObjs[currentTurn - 2].SetActive (false);
		infoObjs[currentTurn - 1].SetActive (true);

		switch(currentTurn){
		case 6:
			mySource.Play ();
			break;
		case 9:
			currentTurnText.text = "Einde";
			break;
		}
	}
	public void StartNextTurn(){
		playOnMobile = true;
		mobileOverlayImg.enabled = true;
		mobileOverlayImg.canvasRenderer.SetAlpha (0.0f);
		mobileOverlayImg.CrossFadeAlpha (0.7f,1f,false);
	}
}
