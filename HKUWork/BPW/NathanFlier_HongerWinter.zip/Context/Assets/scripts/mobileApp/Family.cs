﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Family : MonoBehaviour {
	private PlayerData dataScript;

	public GameObject familyPanel;

	public List<Person> familyMembers = new List<Person>();
	public List<string> randomNames = new List<string> ();
	public List<string> hiderNames = new List<string> ();
	private int amountOfFamilyMembers = 3;

	public GameObject[] personObjs;
	private Image[] personsImgs = new Image[6];
	private GameObject[] feedButtons = new GameObject[6];
	private GameObject[] healButtons = new GameObject[6];
	private Text[] nameLabels = new Text[6];
	public Image fuelImg;
	public Sprite emptyHeater;
	public Sprite burningHeater;
	public Sprite gravestone;
	private Text fuelText;
	private int requiredFuel = 1;

	private bool initialized;

	public void Init(PlayerData pScript){//initialized when the first turn begins
		fuelText = fuelImg.gameObject.GetComponentInChildren <Text>();
		dataScript = pScript;
		amountOfFamilyMembers = pScript.amountOfActiveMembers;

		for(int i = 0; i < personObjs.Length; i ++){
			feedButtons [i] = personObjs [i].transform.FindChild ("FeedButton").gameObject;
			healButtons [i] = personObjs [i].transform.FindChild ("HealButton").gameObject;
			nameLabels [i] = personObjs [i].transform.FindChild ("NameLabel").GetComponent <Text>();
			personsImgs [i] = personObjs [i].GetComponent <Image> ();
			if(i == personObjs.Length - 1){
				feedButtons [i].SetActive (false);
				healButtons [i].SetActive (false);
			}
		}

		for(int i = 0; i < amountOfFamilyMembers; i ++){
			int rndmIndx = Random.Range (0, randomNames.Count);
			Person p = new Person(randomNames[rndmIndx]);
			randomNames.RemoveAt (rndmIndx);
			familyMembers.Add (p);

			feedButtons [i] = personObjs [i].transform.FindChild ("FeedButton").gameObject;
			healButtons [i] = personObjs [i].transform.FindChild ("HealButton").gameObject;
			nameLabels [i] = personObjs [i].transform.FindChild ("NameLabel").GetComponent <Text>();

			healButtons [i].SetActive (false);
			nameLabels [i].text = p.name;
		}
		for(int i = amountOfFamilyMembers; i < personObjs.Length; i ++){
			personObjs [i].SetActive (false);
		}
		initialized = true;
	}

	public void ActivateFamilyPanel(bool activate){
		familyPanel.SetActive (activate);
	}

	public void ButtonFeedPerson(int indx){
		if (dataScript.EnoughResources ("eten",1)) {
			if (indx == 5)
				indx = familyMembers.Count - 1;
			familyMembers [indx].hungry = false;
			feedButtons [indx].SetActive (false);
			dataScript.AlterFoodAmount (-1);
		}
	}
	public void ButtonTreatPerson(int indx){
		if (dataScript.EnoughResources ("medicijnen",1)) {
			if (indx == 5)
				indx = familyMembers.Count - 1;
			familyMembers [indx].healthState = Health.healthy;
			healButtons [indx].SetActive (false);
			dataScript.AlterMedicineAmount (-1);
			if(!familyMembers[indx].isHider)
				dataScript.amountOfActiveMembers++;
		}
	}
	public void HeatHouse(){
		if (fuelImg.sprite == emptyHeater) {	
			if (dataScript.EnoughResources ("brandstof", requiredFuel)) {
				dataScript.AlterFuelAmount (-requiredFuel);
				fuelImg.sprite = burningHeater;
				fuelText.enabled = false;
			}
		}
	}
		
	public void AddHider(out string hiderName){
		hiderName = hiderNames[Random.Range (0,hiderNames.Count)];
		Person hider = new Person (hiderName, true);
		familyMembers.Add (hider);
		amountOfFamilyMembers++;

		int hiderIndx = familyMembers.Count - 1;
		feedButtons [hiderIndx] = feedButtons [5];
		healButtons [hiderIndx] = healButtons [5];
		nameLabels [hiderIndx] = nameLabels [5];
		personsImgs [hiderIndx] = personsImgs [5];

		personObjs [5].SetActive (true);
		nameLabels [hiderIndx].text = hiderName;
		feedButtons [hiderIndx].SetActive (true);
	}
	public void Razzia(out string foundHiderText){
		foundHiderText = "Dat viel best mee, er was niks waar ze zich boos om hadden kunnen maken.";
		foreach(Person p in familyMembers){
			if (p.isHider && p.healthState != Health.dead) {
				if(Random.value < 0.8f){
					int hiderIndx = familyMembers.IndexOf (p);
					KillFamilyMember (hiderIndx);
					foundHiderText = "Ze hebben " + p.name + " meegenomen...";
				}else
					foundHiderText = "Ze hebben " + p.name + " gelukkig niet gevonden!";
			}
		}
	}
	public void Disease(Person p){
		MakeSick (familyMembers.IndexOf (p));
	}

	public void NextTurn(bool beginHungerWinter = false){
		if (initialized) {	
			ActivateFamilyPanel (true);
			for (int i = 0; i < amountOfFamilyMembers; i++) {
				Person currentPerson = familyMembers[i]; 
				if (currentPerson.healthState != Health.dead) {
					if (currentPerson.healthState == Health.sick) {
						KillFamilyMember (i);
					} else {
						if (currentPerson.hungry) {
							MakeSick (i);
						}
						feedButtons [i].SetActive (true);
						currentPerson.hungry = true;
					}
				}
			}
			if (fuelImg.sprite == emptyHeater)
				LackOfFuel ();

			fuelImg.sprite = emptyHeater;
			fuelText.enabled = true;
			if (beginHungerWinter) {
				fuelText.text = "2";
				requiredFuel = 2;
			}
		}
	}

	void LackOfFuel(){
		if (dataScript.amountOfActiveMembers > 0) {	
			List<int> hPersonsIndxs = new List<int> ();
			for (int i = 0; i < amountOfFamilyMembers; i ++) {
				if (familyMembers[i].healthState == Health.healthy) {
					hPersonsIndxs.Add (i);
				}
			}
			int rndmIndx = Random.Range (0, hPersonsIndxs.Count);
			int personIndx = hPersonsIndxs [rndmIndx];
			MakeSick (personIndx);
		}
	}

	void MakeSick(int personIndx){
		familyMembers [personIndx].healthState = Health.sick;
		healButtons [personIndx].SetActive (true);
		if(!familyMembers[personIndx].isHider)
			dataScript.amountOfActiveMembers--;
	}
	void KillFamilyMember(int personIndx){
		familyMembers [personIndx].healthState = Health.dead;
		healButtons [personIndx].SetActive (false);
		feedButtons [personIndx].SetActive (false);
		personsImgs [personIndx].sprite = gravestone;
	}

	public List<string> RemainingFamilyMembers(){
		List<string> allNames = new List<string>();
		foreach(Person p in familyMembers){
			if (p.healthState != Health.dead) 
				allNames.Add (p.name);
		}
		return allNames;
	}
	public Person RandomHealthyFamilyMember(){
		List<Person> allHealthyPersons = new List<Person> ();
		foreach(Person p in familyMembers){
			if (p.healthState == Health.healthy) 
				allHealthyPersons.Add (p);
		}
		if (allHealthyPersons.Count > 0)
			return allHealthyPersons [Random.Range (0, allHealthyPersons.Count)];
		else
			return null;
	}
}

[System.Serializable]
public class Person{
	public bool hungry = true;
	public Health healthState = Health.healthy;
	public string name;
	public bool isHider;
	public Person(string name, bool isHider = false){
		this.name = name;
		this.isHider = isHider;
	}
}
	
public enum Health{
	healthy,sick,dead
}