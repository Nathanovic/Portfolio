﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Trade : MonoBehaviour {
	private Client clientScript;
	private PlayerData dataScript;

	//trade creation
	private bool canTrade = true;
	public GameObject tradePanelObj;
	public TradeFamilyID myFamID = TradeFamilyID.Boeren1;
	private TradeFamilyID tradeFamID = TradeFamilyID.Boeren1;
	private int offerAmount = 1;
	private Products offerProduct = Products.eten;
	private int requestAmount = 1;
	private Products requestProduct = Products.brandstof;
	//trade offer
	public GameObject tradeOfferObj;
	private Text tradeOfferText;
	public TradeOffer currentTradeOffer;
	//trade feedback
	public GameObject tradeFeedbackObj;
	private Text tradeFeedbackText;

	void Start(){
		dataScript = GetComponent <PlayerData> ();
		tradeOfferText = tradeOfferObj.transform.FindChild ("TradeOffer").GetComponent <Text>();
		tradeFeedbackText = tradeFeedbackObj.transform.FindChild ("TradeFeedback").GetComponent <Text> ();
	}

	public void Init(Client c) {
		clientScript = c;
		myFamID = GetFamilyID (c.familyName, c.clientID);
		c.clientTradeID = myFamID;
		c.SendData ("CID|" + myFamID.ToString ());

		Text famText = GameObject.Find ("FamilyName").GetComponent<Text> ();
		famText.text = myFamID.ToString ();
	}

	private TradeFamilyID GetFamilyID(string fName, int cID){
		switch(fName){
		case "boeren":
			if (cID == 1)
				return TradeFamilyID.Boeren1;
			else
				return TradeFamilyID.Boeren2;
		case "brandstoffers":
			if (cID == 1)
				return TradeFamilyID.Houthakkers1;
			else
				return TradeFamilyID.Houthakkers2;
		case "doktoren":
			return TradeFamilyID.Doktoren;
		default:
			return TradeFamilyID.FamilyIDNotFound;
		}
	}

	public void ActivateTradePanel(bool activate){
		if(canTrade)
			tradePanelObj.SetActive (activate);
	}

	public void SetFamID(int id){
		tradeFamID = (TradeFamilyID)id;
	}
	public void SetOfferAmount(string amountStr){
		int amount = 0;
		if (int.TryParse (amountStr, out amount)) {
			offerAmount = amount;
		}
	}
	public void SetOfferProduct(int productID){
		offerProduct = (Products)productID;
	}
	public void SetRequestAmount(string amountStr){
		int amount = 0;
		if (int.TryParse (amountStr, out amount)) {
			requestAmount = amount;
		}
	}
	public void SetRequestProduct(int productID){
		requestProduct = (Products)productID;
	}

	public void SendTradeRequest(){
		if(dataScript.EnoughResources (offerProduct.ToString (), offerAmount) && tradeFamID != myFamID){	
			string offerData = "|" + myFamID.ToString () + "|" + offerAmount.ToString () + "|" + offerProduct.ToString ();
			string requestData = "|" + tradeFamID.ToString () + "|" + requestAmount.ToString () + "|" + requestProduct.ToString ();
			string data = "CT" + offerData + requestData;
			clientScript.SendData (data);
			canTrade = false;
			tradePanelObj.SetActive (false);
			tradeFeedbackText.text = "Handelsverzoek verstuurd!";
			tradeFeedbackObj.SetActive (false);
		}
	}

	public void ShowTradeOffer(string tradeData){
		currentTradeOffer = new TradeOffer (tradeData, myFamID.ToString ());
		tradeOfferText.text = currentTradeOffer.TradeOfferText ();
		tradeOfferObj.SetActive (true);
		tradePanelObj.SetActive (false);
	}
	public void AcceptTradeOfferButton(){
		tradeOfferObj.SetActive (false);
		if (dataScript.EnoughResources (currentTradeOffer.requestProduct, currentTradeOffer.requestAmount)) {
			ModifyProductAmount (currentTradeOffer.offerProduct, currentTradeOffer.offerAmount);
			ModifyProductAmount (currentTradeOffer.requestProduct, -currentTradeOffer.requestAmount);
			clientScript.SendData (currentTradeOffer.AcceptOfferData ());
		} 
	}
	public void RejectTradeOfferButton(){
		tradeOfferObj.SetActive (false);
		print (currentTradeOffer.RejectOfferData ());
		clientScript.SendData (currentTradeOffer.RejectOfferData ());//gebeurt nog niks mee uit luiheid
	}

	public void TradeOfferAccepted(string tradeData){
		string[] aData = tradeData.Split ('|');
		string fbText = "Je hebt " + aData [0] + " " + aData [1] + " ontvangen van " + aData [2] + " in ruil voor " + aData [3] + " " + aData [4];

		int acceptedAmount = int.Parse (aData[0]);
		int givenAmount = int.Parse (aData [3]);
		ModifyProductAmount (aData[1], acceptedAmount);
		ModifyProductAmount (aData[4], -givenAmount);

		tradeFeedbackText.text = fbText;
		tradeFeedbackObj.SetActive (true);
	}
	void ModifyProductAmount(string productName, int alterValue){
		if(productName == "eten"){
			dataScript.AlterFoodAmount (alterValue);
		}else if(productName == "brandstof"){
			dataScript.AlterFuelAmount (alterValue);
		}else if(productName == "medicijnen"){
			dataScript.AlterMedicineAmount (alterValue);
		}else{
			Debug.LogWarning ("Onbekend product: " + productName);
		}
	}

	public void TradeReset(){//wordt iedere beurt aangeroepen
		canTrade = true;
		tradeOfferObj.SetActive (false);
		tradePanelObj.SetActive (false);
		tradeFeedbackObj.SetActive (false);
	}
}

[System.Serializable]
public class TradeOffer{
	public TradeOffer(string data, string fID){
		myFamID = fID;

		string[] tradeOfferData = data.Split ('|');
		tradeOfferClient = tradeOfferData [0];
		offerAmount = int.Parse (tradeOfferData [1]);
		offerProduct = tradeOfferData [2];
		requestAmount = int.Parse (tradeOfferData [4]);
		requestProduct = tradeOfferData [5];
	}

	public string myFamID;
	public string tradeOfferClient;

	public int offerAmount;
	public string offerProduct;
	public int requestAmount;
	public string requestProduct;

	public string TradeOfferText(){
		return tradeOfferClient + " wil met je handelen!\n Je krijgt " + offerAmount + " " + offerProduct + " voor " + requestAmount + " " + requestProduct;
	}
	public string AcceptOfferData(){
		return "CATO|" + tradeOfferClient + "|" + requestAmount + "|" + requestProduct + "|" + myFamID + "|" + offerAmount + "|" + offerProduct;
	}
	public string RejectOfferData(){
		return "CRTO|" + tradeOfferClient + "|" + myFamID;
	}
}

public enum TradeFamilyID{
	Boeren1,Boeren2,
	Houthakkers1,Houthakkers2,
	Doktoren,
	FamilyIDNotFound
}
public enum Products{
	eten,
	brandstof,
	medicijnen
}
