﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {
	public static GameManager instance{ get; set;}

	public GameObject clientPrefab;
	public GameObject serverPrefab;

	private Menu menuScript;
	public string hostAddress = "";
	public int port = 8091;

	public GameObject server;
	public GameObject client;

	public string externIP = "94.215.43.141";

	void Awake () {
		instance = this;
		DontDestroyOnLoad (gameObject);
	}
	void Start(){
		menuScript = GameObject.Find ("MenuManager").GetComponent <Menu> ();

		//GameObject.Find ("PortInputField").SetActive (false);
		if(Application.isMobilePlatform){
			GameObject.Find ("InfoscreenStuff").SetActive (false);
			//hostAddress = "192.168.178.31";
			hostAddress = externIP;
		}
	}
	public void SetHostAddress(string newAddress){
		hostAddress = newAddress;
	}
	public void SetPort(string newPort){
		port = int.Parse (newPort);
	}

	public void ButtonHost(){
		try{
			server = GameObject.Instantiate (serverPrefab) as GameObject;
			Server s = server.GetComponent <Server>();
			s.Init ();

			Connect (hostAddress, "Host");//hoort localip te zijn
		}catch(Exception e){
			string errorMessage = "Error: " + e.Message;
			Debug.Log ("Error: " + e.Message);
			menuScript.EnterLobby (true, errorMessage);
		}
	}
	public void ButtonConnect(int famId){
		FamilyClass famClass = (FamilyClass)famId;
		string familyName = famClass.ToString ();
		Connect (hostAddress, familyName);
	}

	public void ButtonBack(){
		if (server != null)
			Destroy (server);
		if (client != null)
			Destroy (client);
		menuScript.LeaveLobby ();
	}

	public void ButtonStartGame(){
		if (server != null) {
			Server serverScript = server.GetComponent <Server> ();
			serverScript.BroadcastAll ("SSG");//StartGame
		} else {
			Client clientScript = client.GetComponent <Client> ();
			clientScript.SendData ("CSGR");//StartGameRequest
		}
	}

	private void Connect(string hostAddr, string famName){
		string errorMessage = "";
		client = GameObject.Instantiate (clientPrefab) as GameObject;
		Client c = client.GetComponent <Client>();
		c.ConnectToServer (hostAddr, port, out errorMessage);
		c.familyName = famName;
		bool isHost = false;
		switch (famName) {
		case "Host":
			isHost = true;
			c.clientRole = ClientRole.host;
			break;
		case "beamerPC":
			isHost = true;
			c.clientRole = ClientRole.beamerPC;
			break;
		default:
			c.clientRole = ClientRole.client;
			break;
		}
		menuScript.EnterLobby (isHost, errorMessage);
	}

	public void StartGame(ClientRole cRole){
		if (cRole != ClientRole.client)
			SceneManager.LoadScene ("InfoScreen");
		else 
			SceneManager.LoadScene ("Game");
	}
}

public enum FamilyClass{
	boeren,
	brandstoffers,
	doktoren,
	beamerPC
}
