﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraModelBase : MonoBehaviour, IZoomable {
	#region IZoomable implementation
	public float lerpSpeed{ get; set;}
	public bool isLerpingPosition{ get; set;}
	public bool isInLerpControl { get; set; }

	public float maxDistDelta{ get; set;}
	public float defaultDistToTarget { get; set; }
	public float currentDistToTarget{
		get{ 
			return Vector3.Distance (transform.position, rotateOrigin.position);
		}
	}

	public void IZoomableSetup () {
		lerpSpeed = 7f;
		isLerpingPosition = false;
		isInLerpControl = false;
		maxDistDelta = 0.1f;
		defaultDistToTarget = Vector3.Distance (transform.position, rotateOrigin.position);
	}

	public void DisableCameraControl(){
		isInLerpControl = true;
	}

	public void ZoomCamera (float remainingDist, out bool reachedTarget){
		isLerpingPosition = false;
		print ("Camera zoom");
		Vector3 dirFromTarget = transform.position - rotateOrigin.position;
		Vector3 endPos = rotateOrigin.position + dirFromTarget.normalized * remainingDist;
		if (Vector3.Distance (endPos, transform.position) > maxDistDelta) {
			Vector3 pos = Vector3.MoveTowards (transform.position, endPos, lerpSpeed * Time.deltaTime);
			transform.position = pos;
			reachedTarget = false;
		} else {
			reachedTarget = true;
		}
	}
	public void ZoomToDefaultPos(){
		StartCoroutine (LerpZoomToDefaultPos());
	}
	public IEnumerator LerpZoomToDefaultPos (){
		isLerpingPosition = false;
		print ("Camera reset zoom");
		yield return null;
		isLerpingPosition = true;

		Vector3 targetPos = rotateOrigin.position;
		bool zoomIn = false;
		if (currentDistToTarget > defaultDistToTarget) {
			zoomIn = true;
			targetPos.y = transform.position.y;
		}

		Vector3 moveDir = (targetPos - transform.position).normalized;
		moveDir = transform.InverseTransformDirection (moveDir);
		if (currentDistToTarget < defaultDistToTarget)
			moveDir *= -1f;

		while(isLerpingPosition && ((zoomIn && (currentDistToTarget - defaultDistToTarget) > maxDistDelta) || (!zoomIn && (currentDistToTarget - defaultDistToTarget) < maxDistDelta))){
			transform.Translate (moveDir * lerpSpeed * Time.deltaTime, Space.Self);
			yield return null;
		}
		if (isLerpingPosition)
			isInLerpControl = false;
	}
	#endregion

	public Transform rotateOrigin;
}
