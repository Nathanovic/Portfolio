﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraModel : CameraModelBase{
	public float horizontalRotationSpeed;
	public float verticalRotationSpeed;
	private Transform cameraTr;
	private Vector3 lastPlayerPos;
	public Vector3 playerMovement;

	public int maxXAngle = 47;
	public int minXAngle = 7;

	void Start(){
		transform.SetParent (null);
		cameraTr = transform.Find ("CameraTr");
		lastPlayerPos = rotateOrigin.position;

		IZoomableSetup ();
	}

	public float distToTarget;
	void LateUpdate () {
		if (!isInLerpControl) {
			MoveCamera ();
			RotateCameraAroundPlayer ();
			ResetCameraTrRotation ();
		}
		UpdateLastPlayerPos ();
		AimCameraAtPlayer ();

		distToTarget = currentDistToTarget;
	}

	#region player controls camera
	void MoveCamera(){
		playerMovement = rotateOrigin.transform.position - lastPlayerPos;
		transform.Translate (playerMovement, Space.World);
		Debug.DrawRay (transform.position, playerMovement, Color.red);
	}
	void RotateCameraAroundPlayer(){
		float inputX = Input.GetAxis ("Horizontal2");
		float inputZ = -Input.GetAxis ("Vertical2");
		if(inputX != 0){
			transform.RotateAround (rotateOrigin.position, Vector3.up, horizontalRotationSpeed * Time.deltaTime * inputX);
		}
		float xRot = transform.rotation.eulerAngles.x;
		if (xRot > 180)
			xRot -= 360;
		if((inputZ < 0 && xRot > minXAngle) || (inputZ > 0 && xRot < maxXAngle)){
			transform.RotateAround (rotateOrigin.position, transform.right, verticalRotationSpeed * Time.deltaTime * inputZ);
		}
	}
	void ResetCameraTrRotation(){
		Vector3 cameraTrRot = cameraTr.rotation.eulerAngles;
		cameraTrRot.x = cameraTrRot.z = 0;
		cameraTr.rotation = Quaternion.Euler (cameraTrRot);
	}
	#endregion

	void UpdateLastPlayerPos(){
		lastPlayerPos = rotateOrigin.position;		
	}
	void AimCameraAtPlayer(){
		transform.LookAt (rotateOrigin);
	}
}
