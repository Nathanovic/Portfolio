﻿using System.Collections;
using UnityEngine;

public interface IZoomable{
	float lerpSpeed{ get; set;}
	bool isLerpingPosition{ get; set;}
	bool isInLerpControl{ get; set;}

	float maxDistDelta{ get; set;}
	float defaultDistToTarget{ get; set;}
	float currentDistToTarget{ get;}

	void IZoomableSetup ();
	void DisableCameraControl();

	void ZoomCamera (float remainingDist, out bool reachedTarget);
	void ZoomToDefaultPos ();
	IEnumerator LerpZoomToDefaultPos ();
}
