﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <tutorial>
/// dit script kijkt of er targets in de fov van de character(boar) zijn
/// dit script wordt alleen gerunned als deze character in de buurt van de speler is
/// </tutorial>
[RequireComponent(typeof(Enemy))]
public class FieldOfView : MonoBehaviour, IDistanceDependable {

	public bool playerIsClose; 
	private WolfStateHandler wolfFocusScript;
	private bool playerIsFocussed{
		get{ return wolfFocusScript.activityState == ActivityState.sneak ? true : false;}
	}
	private Enemy aggressiveAIScript;
	[Range(0,2f)]
	public float viewYOffset = 0.5f;
	public float viewRadius;
	[Range(0,360)]
	public float viewAngle;

	public LayerMask targetLM;
	public LayerMask focusedObstacleLM;
	public LayerMask obstacleLM;

	public Transform visibleTarget;

	void Start(){
		aggressiveAIScript = GetComponent <Enemy> ();
		wolfFocusScript = GameObject.FindGameObjectWithTag ("Player").GetComponent <WolfStateHandler> ();
		StartCoroutine (SlowUpdate (0.3f));
	}

	IEnumerator SlowUpdate(float delay){
		while(true){
			yield return new WaitForSeconds (delay);
			if (playerIsClose && aggressiveAIScript.attackableTarget == null) {
				visibleTarget = null;
				FindVisibleTargets ();
			}
		}
	}

	public void FindVisibleTargets(){
		Vector3 transformPos = transform.position;
		transformPos.y += viewYOffset;
		Collider[] targetsInViewRadius = Physics.OverlapSphere (transformPos, viewRadius, targetLM);
		foreach(Collider targetColl in targetsInViewRadius){
			Vector3 targetPos = targetColl.transform.position;
			targetPos.y += viewYOffset;
			Vector3 dirToTarget = (targetPos - transformPos).normalized;

			if (Vector3.Angle (transform.forward, dirToTarget) < viewAngle / 2) {		
				float distToTarget = Vector3.Distance (targetPos, transformPos);
				LayerMask obstacleCheckLM = playerIsFocussed ? focusedObstacleLM : obstacleLM;
				if (!Physics.Raycast (transformPos, dirToTarget, distToTarget, obstacleCheckLM)) {
					visibleTarget = (targetColl.transform);
					aggressiveAIScript.SetAttackableTarget (visibleTarget);
				} 
			}
		}
	}
	public Vector3 DirFromAngle(float angleInDegrees){
		angleInDegrees += transform.rotation.eulerAngles.y;
		return new Vector3 (Mathf.Sin (angleInDegrees * Mathf.Deg2Rad), 0, Mathf.Cos (angleInDegrees * Mathf.Deg2Rad));
	}

	#region IDistanceDependable implementation

	public void ActivateStuff ()
	{
		playerIsClose = true;
	}

	public void DeactivateStuff ()
	{
		playerIsClose = false;
	}

	#endregion
}
