﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class EndingStory : MonoBehaviour {	
	Transform camTr{
		get{ 
			return GameManager.instance.cameraTr;
		}
	}
	CanvasGroup cvg;
	bool storyStarted;

	private Text storyText;
	public string[] storyParts;
	public int storyPartID;
	public float startANotificationTime = 4f;

	void Start () {
		cvg = GetComponent <CanvasGroup> ();
		storyText = GetComponentInChildren <Text> ();
		storyText.text = storyParts [0];
	}

	void Update(){
		if(storyStarted){
			RotateToCamera ();
			if(Input.GetButtonUp ("JumpAttack")){
				NextPart ();
			}
		}
	}

	void OnTriggerEnter(Collider coll){
		if(coll.tag == "Player"){
			storyStarted = true;
			RotateToCamera ();
			GameManager.instance.playerCanMove = false;
			cvg.alpha = 1f;
			Invoke ("ShowNotification", startANotificationTime);
		}
	}
	void ShowNotification(){
		NotificationView.instance.ShowNotification ("Press A to talk");		
	}

	void NextPart(){
		if (storyPartID != (storyParts.Length - 1)) {
			storyPartID++;
			storyText.text = storyParts [storyPartID];
		} else {
			GameManager.instance.CallGameEnding ("The end of this demo.\nThank you for playing!");
			storyStarted = false;
		}
	}

	void RotateToCamera(){Vector3 dir = transform.position - camTr.transform.position;
		dir.y = 0;
		transform.rotation = Quaternion.LookRotation (dir);
	}
}

