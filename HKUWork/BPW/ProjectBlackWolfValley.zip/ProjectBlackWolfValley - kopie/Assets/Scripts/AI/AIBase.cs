﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBase : MonoBehaviour {
	[Header("Standard AI variables:")]
	public AIState myState;
	public Transform target;

	private Animator anim;
	[HideInInspector]public float currentSpeed;

	public float rotateSpeed = 0.5f;
	public float movespeed = 3f;

	public Patroller patrolScript;

	void Awake(){
		anim = GetComponent <Animator> ();
		currentSpeed = movespeed;
		patrolScript.PatrolSetup (this, transform);
	}

	public void Update(){
		if (myState == AIState.standing || myState == AIState.walking)
			patrolScript.PatrolUpdate ();
		
		if (myState == AIState.walking || myState == AIState.charging) {
			RotateToTarget ();
			MoveToTarget ();
			if(myState == AIState.charging)
				AggressiveUpdate ();
		}
	}

	public virtual void AggressiveUpdate(){}

	//called by Patroller
	//called by Enemy
	public void SetNewTarget(Transform t, AIState newState){
		target = t;
		myState = newState;
		anim.SetInteger ("moveState", (int)newState);
	}

	void RotateToTarget(){
		Vector3 targetPos = target.position;
		targetPos.y = transform.position.y;
		Vector3 lookDir = targetPos - transform.position;
		transform.rotation = Quaternion.Lerp (transform.rotation, Quaternion.LookRotation (lookDir), rotateSpeed * Time.deltaTime);		
	}
	void MoveToTarget(){
		transform.Translate (transform.forward * currentSpeed * Time.deltaTime, Space.World);
	}
}

public enum AIState{
	standing, walking, charging
}
