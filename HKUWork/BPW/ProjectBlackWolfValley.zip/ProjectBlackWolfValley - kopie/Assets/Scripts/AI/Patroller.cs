﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//wordt volledig aangestuurd vanuit AIBase
//alles wat dit script terug geeft is een standingState of een patrollingState en de target waar de transform heen moet lopen
[System.Serializable]
public class Patroller {
	public Transform[] allWaypoints;
	private int targetWaypointID;
	public Transform patrolTarget{
		get{
			return allWaypoints [targetWaypointID];	
		}
	}

	private AIBase aiScript;
	private Transform transform;

	public float maxWaypointDistance = 0.5f;
	public float minWaitAtWaypointTime = 0.5f;
	public float maxWaitAtWaypointTime = 3f;
	private float waitAtWaypointTime;
	private float startWaitingTime;

	public void PatrolSetup(AIBase ai, Transform t){
		aiScript = ai;
		transform = t;
		StartPatrolling ();
	}
	public void StartPatrolling(){
		waitAtWaypointTime = NewWaitAtWaypointTime ();
		aiScript.SetNewTarget (patrolTarget, AIState.walking);
	}

	public void PatrolUpdate(){
		if (aiScript.myState == AIState.walking) {
			Vector3 targetPos = patrolTarget.position;
			targetPos.y = transform.position.y;
			if (Vector3.Distance (targetPos, transform.position) < maxWaypointDistance) {//could be optimized
				aiScript.SetNewTarget (null, AIState.standing);
				startWaitingTime = Time.time;
			}
		} else {
			if (Time.time - startWaitingTime > waitAtWaypointTime) {
				NextWaypoint ();				
				aiScript.SetNewTarget (patrolTarget, AIState.walking);
			}
		}
	}
	void NextWaypoint (){
		if (targetWaypointID != (allWaypoints.Length - 1)) {
			targetWaypointID++;
		} else
			targetWaypointID = 0;
		waitAtWaypointTime = NewWaitAtWaypointTime ();
	}

	float NewWaitAtWaypointTime(){
		return (Random.Range (minWaitAtWaypointTime, maxWaitAtWaypointTime));
	}
}
