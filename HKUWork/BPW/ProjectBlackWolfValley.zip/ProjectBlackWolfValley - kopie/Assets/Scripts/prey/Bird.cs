﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour{
	public float endY = 6;
	private float startY;
	public float flySpeed = 5;
	public float maxSpeed = 5;

	public FlyState flyState;
	public float remainingUpTime;
	public float stayUpTime;

	public bool isDead;
	Rigidbody rb;
	Animator anim;
	AudioSource mySource;

	//public delegate void CaughtMeAction ();
	//public event CaughtMeAction onCaugtMe;

	public AudioClip[] scaredClips;

	void Start(){
		startY = transform.position.y;
		rb = GetComponent <Rigidbody> ();
		anim = GetComponentInChildren <Animator> ();
		mySource = GetComponent <AudioSource> ();
	}

	void Update(){
		transform.Translate (transform.up * flySpeed * Time.deltaTime);

		if(flyState == FlyState.flyUp && !isDead){
			if (transform.position.y >= endY){
				flySpeed = 0; 
				flyState = FlyState.stay;
				remainingUpTime = stayUpTime;
			}
		}else if(flyState == FlyState.stay){
			if (remainingUpTime > 0) {
				remainingUpTime -= Time.deltaTime;
			} else{
				flySpeed = -maxSpeed * 0.3f;
				flyState = FlyState.flyDown;
			}
		}else if(flyState == FlyState.flyDown && transform.position.y <= startY){
			flyState = FlyState.none;
			anim.SetBool ("fly", false);
			flySpeed = 0;
			rb.isKinematic = false;
		}
	}

	void OnTriggerEnter(Collider coll){
		if(coll.transform.parent != null && coll.transform.parent.tag == "Player" && flyState != FlyState.flyUp && !isDead){
			flyState = FlyState.flyUp;
			AudioManager.instance.PlayRandomAudioClip (scaredClips, mySource);
			anim.SetBool ("fly", true);
			flySpeed = maxSpeed;
			rb.isKinematic = true;
		}
	}
	void OnCollisionStay(Collision coll){
		if(coll.collider.tag == "Ground" && isDead){
			rb.isKinematic = true;
			GetComponent <BoxCollider>().isTrigger = true;
			Destroy (transform.GetChild (0).gameObject);
			StartCoroutine (DestroyOverTime ());
		}
	}
	IEnumerator DestroyOverTime(){
		Renderer myR = GetComponentInChildren <Renderer> ();
		float t = 0f;
		while(t < 1f){
			yield return 0;
			t += Time.deltaTime;
			myR.material.color = new Color(1f - t,1f - t,1f - t);
		}
		Destroy (gameObject);
	}

	public void CaughtMe(){
		Destroy (anim);
		isDead = true;
		flyState = FlyState.none;
		rb.isKinematic = false;
		flySpeed = 0;
		transform.tag = "DeadPrey";
		GameManager.instance.AddScore ();
		//onCaugtMe ();
	}

	public enum FlyState{
		none,flyUp,stay,flyDown,dead
	}
}
