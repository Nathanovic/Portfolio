﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdEatable : MonoBehaviour, IEateable  {

	public int FoodAmount{ get; set;}
	public int RemainingFood{ get; set;}

	private Bird birdScript;
	public GameObject eatableMarker;

	void Start(){
		FoodAmount = RemainingFood = 3;
		birdScript = GetComponent <Bird> ();
		//birdScript.onCaugtMe += EnableEatFromMe;
		eatableMarker = transform.GetChild (1).gameObject;
	}
	public void EnableEatFromMe(){
		eatableMarker.SetActive (true);
		eatableMarker.transform.rotation = Quaternion.Euler (new Vector3 (0, -90, 0));
	}
	public void EatFromMe(){
		if(RemainingFood > 0){
			RemainingFood--;
			if(RemainingFood == 0){
				Destroy (gameObject);
			}
		}
	}
}
