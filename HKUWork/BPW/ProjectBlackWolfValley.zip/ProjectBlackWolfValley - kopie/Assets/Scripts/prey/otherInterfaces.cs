﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IEateable{
	int FoodAmount { get; set;}
	int RemainingFood { get; set;}

	void EnableEatFromMe();
	void EatFromMe();
}
