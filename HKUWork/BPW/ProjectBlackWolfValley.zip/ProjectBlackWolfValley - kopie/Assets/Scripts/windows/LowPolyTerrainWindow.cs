﻿//using System.Collections;
//using UnityEngine;
//using UnityEditor;
//
////https://www.youtube.com/watch?v=ko1_BpGnZdw&index=2&list=PL4CCSwmU04MiCnps1DRmwIEEH7gP9X3qq
//public class LowPolyTerrainWindow : EditorWindow {	
//	public Color headerColor = new Color(0.04f,0.55f,0.32f,1f);
//	public Texture2D headerSectionTexture;
//	public Rect headerSection;
//
//	[MenuItem("Window/Low poly terrain")]
//	static void OpenWindow(){
//		LowPolyTerrainWindow window = (LowPolyTerrainWindow)GetWindow (typeof(LowPolyTerrainWindow));
//		window.minSize = new Vector2 (300,500);
//		window.Show ();
//	}
//
//	//similar to void Start
//	void OnEnable(){
//		InitTexture ();
//	}
//
//	void InitTexture(){
//		headerSectionTexture = new Texture2D (1,1);
//		headerSectionTexture.SetPixel (0, 0, headerColor);
//		headerSectionTexture.Apply ();
//	}
//
//	void OnGUI(){
//		DrawLayout ();
//	}
//
//	void DrawLayout(){
//		headerSection.x = 0;
//		headerSection.y = 0;
//		headerSection.width = Screen.width;
//		headerSection.height = 50;
//
//		GUI.DrawTexture (headerSection, headerSectionTexture);
//	}
//}

