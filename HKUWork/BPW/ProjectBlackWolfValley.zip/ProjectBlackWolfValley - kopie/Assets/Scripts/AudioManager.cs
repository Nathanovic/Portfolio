﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {
	public static AudioManager instance;
	private AudioSource mySource;
	public AudioClip windSound;

	public float windSoundTime = 180f;
	public float pausedPitch = 0.65f;

	public float windSoundStrength = 0.4f;
	public float musicStrength = 0.4f;

	public float sfxVolume;
	public float backgroundVolume = 1f;

	void Start () {
		instance = this;
		mySource = GetComponent <AudioSource> ();
		mySource.volume = musicStrength;
		InvokeRepeating ("PlayWindSound", 0f, windSoundTime);
	}

	public void PlayRandomAudioClip(AudioClip[] clips, AudioSource source){
		int rndmIndx = Random.Range(0,clips.Length);
		source.PlayOneShot (clips[rndmIndx], sfxVolume);
	}

	public void PlayAudioClip(AudioClip clip){
		mySource.PlayOneShot (clip, sfxVolume);
	}

	void PlayWindSound(){
		mySource.PlayOneShot (windSound, windSoundStrength * backgroundVolume);
	}

	public void SetPausedPitch(bool paused){
		float p = paused ? pausedPitch : 1f;
		mySource.pitch = p;
	}

	public void SetSFXVolume(float newV){
		sfxVolume = newV;
	}
	public void SetBGVolume(float newV){
		backgroundVolume = newV;
		mySource.volume = musicStrength * newV;
	}
}
