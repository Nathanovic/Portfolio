﻿using UnityEngine;

public interface IPatrollable{ 
	int TargetWaypointID{get;set;}
	float MaxWaypointDistance{ get; set;}
	float MaxWaitAtWaypointTime{ get; set;}
	float WaitAtWaypointTime{ get; set;}
	float StartWaitingTime{ get; set;}

	void PatrolSetup(int startWPID, float maxDist, float waitTime);
	void PatrolUpdate();
	void NextWaypoint();
}