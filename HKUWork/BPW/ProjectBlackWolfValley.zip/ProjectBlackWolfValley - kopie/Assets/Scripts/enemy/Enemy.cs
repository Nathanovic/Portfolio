﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : AIBase {
	[Header("Aggressive AI variables:")]
	public float chargeSpeed = 5f;
	public float hitDistance;
	public Transform attackableTarget;
	private bool canAttackTarget = true;

	private AudioSource mySource;
	public AudioClip[] standardGrumpSounds;
	public AudioClip[] angryGrumpSounds;

	public float minAudioWaitTime = 1f;
	public float maxAudioWaitTime = 5f;
	public float agressiveTimeMultiplier = 0.4f;

	void Start(){
		mySource = GetComponent <AudioSource> ();
		StartCoroutine (PlayGrumpAudio ());
	}

	public void SetAttackableTarget(Transform t){
		if (canAttackTarget) {
			canAttackTarget = false;
			currentSpeed = chargeSpeed;
			attackableTarget = t;
			SetNewTarget (t, AIState.charging);
		} 
	}

	public override void AggressiveUpdate(){
		if(Vector3.Distance (attackableTarget.position, transform.position) < hitDistance){
			GameManager.instance.CallGameEnding ("You die!");
			SetNewTarget (null, AIState.standing);
			this.enabled = false;
		}
	}

	IEnumerator PlayGrumpAudio(){
		while(true){
			AudioClip[] clipsToPlay = standardGrumpSounds;
			float waitTime = Random.Range (minAudioWaitTime, maxAudioWaitTime);
			if (attackableTarget != null) {
				clipsToPlay = angryGrumpSounds;
				waitTime *= agressiveTimeMultiplier;
			}
			yield return new WaitForSeconds (waitTime);
			AudioManager.instance.PlayRandomAudioClip (clipsToPlay, mySource);
		}
	}
}
