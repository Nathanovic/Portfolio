﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interactable : MonoBehaviour {
	public string popUpText = "Fighting scene";
	public float extraYOffset = -0.25f;
	void OnTriggerEnter(Collider other){
		if(other.transform.root.tag == "Player"){
			Vector3 pos = transform.position;
			pos.y += extraYOffset;
			Notifications.instance.EnableNotification (pos, popUpText);
			Destroy (transform.gameObject);
		}
	}
}
