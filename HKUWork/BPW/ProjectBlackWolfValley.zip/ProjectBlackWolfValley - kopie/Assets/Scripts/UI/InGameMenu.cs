﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class InGameMenu : MonoBehaviour {	
	public CanvasGroup pauseMenu;
	public Button continueButton;	

	public void ShowPausedMenu(bool paused){
		continueButton.Select ();
		pauseMenu.alpha = paused ? 1f : 0f;
	}
	public void Quit(){
		Application.Quit ();
	}
}

