﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NotificationView : MonoBehaviour {
	public CanvasGroup notificationPanel;
	public Text notificationText;

	public float endCooldown = 1.7f;
	public float activeTime = 2f;
	public float lerpTime = 1f;

	public static NotificationView instance;

	void Awake(){
		instance = this;
	}

	public void ShowNotification(string t){
		notificationText.text = t;
		StopAllCoroutines ();
		StartCoroutine (LerpNotificationPanel());
	}

	IEnumerator LerpNotificationPanel(){
		if (notificationPanel.alpha < 0.3f) {
			yield return StartCoroutine (FadeNotificationPanel (1f));
			yield return new WaitForSeconds (lerpTime);
		} else
			notificationPanel.alpha = 1f;
		yield return new WaitForSeconds (activeTime);
		yield return StartCoroutine (FadeNotificationPanel (0f));
		yield return new WaitForSeconds (endCooldown + lerpTime);
	}

	IEnumerator FadeNotificationPanel(float endA){
		float startA = notificationPanel.alpha;
		float t = 0;
		while(t < 1f){
			t += Time.deltaTime / lerpTime;
			notificationPanel.alpha = Mathf.Lerp (startA,endA,t);
			yield return null;
		}
	}
}
