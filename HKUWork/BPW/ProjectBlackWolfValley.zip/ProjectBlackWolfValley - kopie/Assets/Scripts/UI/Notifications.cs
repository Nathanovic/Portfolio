﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Notifications : MonoBehaviour {
	public Transform notificationTr;
	private CanvasGroup notification;
	public Text notificationText;
	private Transform camTr{
		get{ 
			return GameManager.instance.cameraTr;
		}
	}

	public static Notifications instance;

	[Header("values:")]
	public bool isActive;
	public float fadeInTime = 0.37f;
	public float stayActiveTime = 1.7f;
	public float fadeOutTime = 0.7f;
	public float yOffset = 1f;

	void Awake(){
		instance = this;
	}
	void Start(){
		notification = notificationTr.GetComponent <CanvasGroup> ();
	}

	void Update(){
		RotateToCam ();
	}

	public void EnableNotification(Vector3 pos, string info){
		pos.y += yOffset;
		notificationTr.position = pos;
		notificationText.text = info;
		isActive = true;
		isFading = false;
		StartCoroutine(FadeIt ());
	}

	public void DisableNotification(){
		if(isActive)
			StartCoroutine(FadeIt ());
	}

	bool isFading;
	IEnumerator FadeIt(){
		notification.alpha = 0f;
		yield return null;
		isFading = true;

		float t = 0f;
		while(t < 1 && isFading){
			t += Time.deltaTime / fadeInTime;
			notification.alpha = t;
			yield return null;
		}

		t = 0f;
		while(t < stayActiveTime && isFading){
			t += Time.deltaTime;
			yield return null;
		}

		t = 0f;
		while(t < 1 && isFading){
			t += Time.deltaTime / fadeOutTime;
			notification.alpha = 1f-t;
			yield return null;
		}

		isActive = false;
	}

	void RotateToCam(){
		if (isActive) {
			Vector3 dir = notificationTr.position - camTr.transform.position;
			dir.y = 0;
			notificationTr.rotation = Quaternion.LookRotation (dir);
		}
	}
}