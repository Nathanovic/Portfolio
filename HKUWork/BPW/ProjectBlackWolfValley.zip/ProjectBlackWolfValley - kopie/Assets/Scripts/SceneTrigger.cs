﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneTrigger : MonoBehaviour {
	public SceneName loadScene;
	public SceneName unloadScene;

	void LoadScene(SceneName scene){
		GameManager.instance.LoadScene (scene.ToString ());
	}
	void UnLoadScene(SceneName scene){
		GameManager.instance.UnloadScene (scene.ToString ());
	}

	void OnTriggerEnter(Collider other){
		if(other.tag == "Player"){
			LoadScene (loadScene);
			UnLoadScene (unloadScene);
		}
	}
}
