﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class Track : MonoBehaviour {
	public GameObject[] allTrackGameObjects;
	public TrackPart[] allParts;

	public Material[] wolfTrackMaterials;
	public float fadeOutTime = 5f;

	public string foundTrackText = "Wolf trail";

	void Start(){
		if (Application.isPlaying) {
			for (int i = 0; i < allTrackGameObjects.Length; i++) {
				allParts [i].Start ();
				allParts [i].AssignNewMaterial (wolfTrackMaterials[0]);
			}	
		}
	}

	public bool assignPartsData;
	void Update () {
		if(assignPartsData){
			assignPartsData = false;
			AssignAllParts ();
		}
	}

	void AssignAllParts(){
		allParts = new TrackPart[allTrackGameObjects.Length];
		for(int i = 0; i < allTrackGameObjects.Length; i ++){
			allParts [i] = new TrackPart (allTrackGameObjects[i], i);
		}		
	}

	public void ShowTrackNotification(Vector3 notificationPos){
		Notifications.instance.EnableNotification (notificationPos, foundTrackText);		
	}
	public void ShowTrackPart(GameObject trackObj){
		TrackPart visibleTrack = GetTrackByGameObject (trackObj);
		visibleTrack.AssignNewMaterial (wolfTrackMaterials[2]);
	}
	public void HideTrackPart(GameObject trackObj){
		TrackPart visibleTrack = GetTrackByGameObject (trackObj);
		visibleTrack.AssignNewMaterial (wolfTrackMaterials[1]);
		StartCoroutine (visibleTrack.FadeOut (fadeOutTime, wolfTrackMaterials[0]));
	}

	TrackPart GetTrackByGameObject(GameObject trackObj){
		for(int i = 0; i < allParts.Length; i ++){
			if (allTrackGameObjects [i] == trackObj) {
				return allParts [i];
			}
		}
		Debug.LogWarning ("cant find track for object: " + trackObj.name);
		return null;
	}

	[System.Serializable]
	public class TrackPart{
		public int id;
		public GameObject trackObject; 

		public int amountOfTracks;
		public MeshRenderer[] trackRenderers;
		private bool fadeMeOut;

		public TrackPart(GameObject g, int id){
			this.trackObject = g;
			this.id = id;

			amountOfTracks = g.transform.childCount;
		}
		public void Start(){
			trackRenderers = new MeshRenderer[amountOfTracks];
			for(int i = 0; i < amountOfTracks; i ++){
				trackRenderers[i] = trackObject.transform.GetChild (i).GetComponent <MeshRenderer>();
			}
		}

		public void AssignNewMaterial(Material trackMat){
			for(int i = 0; i < amountOfTracks; i ++){
				trackRenderers [i].material = trackMat;
			}
		}

		public IEnumerator FadeOut(float waitTime, Material zeroAlphaMat){
			float t = 0; 
			fadeMeOut = false;
			yield return null;
			fadeMeOut = true;
			while(t < 1 && fadeMeOut){
				t += Time.deltaTime / waitTime;
				yield return 0;
			}
			if(fadeMeOut)
				AssignNewMaterial (zeroAlphaMat);
		}
	} 
}
