﻿using System.Collections;
using UnityEngine;

public class DeadZone : MonoBehaviour {	
	
	void OnTriggerEnter(Collider coll){
		if(coll.tag == "Player"){
			GameManager.instance.CallGameEnding ("The water swallows you...");
		}
	}
}

