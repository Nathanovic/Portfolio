﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideArea : MonoBehaviour {
	public Transform[] distanceDependableTransforms;
	private IDistanceDependable[] distanceDependables;

	public float activationDistance;
	public float activationDistanceSquare;
	public bool active;
	public Transform target;

	public float currentDistSquare;

	void Start(){
		activationDistanceSquare = activationDistance * activationDistance;
		InvokeRepeating ("UpdateActivationCheck", 0.2f, 0.5f);

		distanceDependables = new IDistanceDependable[distanceDependableTransforms.Length];
		for(int i = 0; i < distanceDependableTransforms.Length; i ++){
			distanceDependables[i] = distanceDependableTransforms [i].GetComponent <IDistanceDependable> ();
		}
	}

	void UpdateActivationCheck(){
		currentDistSquare = DistanceToTarget ();
		if (currentDistSquare > activationDistanceSquare) {
			if (active) {
				active = false;
				DeactivateObjects ();
			}
		} else {
			if (!active) {
				active = true;
				ActivateObjects ();
			}
		}
	}

	float DistanceToTarget(){	
		Vector3 targetPos = target.position;
		Vector3 transformPos = transform.position;
		float deltaX = targetPos.x - transformPos.x;
		float deltaY = targetPos.y - transformPos.y;
		float deltaZ = targetPos.z - transformPos.z;
		return(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
	}

	void ActivateObjects(){
		foreach(IDistanceDependable dependable in distanceDependables){
			dependable.ActivateStuff ();
		}
	}
	void DeactivateObjects(){
		foreach(IDistanceDependable dependable in distanceDependables){
			dependable.DeactivateStuff ();
		}
	}
}
