﻿using UnityEngine;

public interface IDistanceDependable{
	void ActivateStuff();
	void DeactivateStuff();
}
