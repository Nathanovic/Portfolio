﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HidingPlace : MonoBehaviour {
	private Collider hideColl;

	void Start () {
		hideColl = GetComponent <Collider> ();
		hideColl.enabled = false;
	}

	public void HideWolfPup(){
		hideColl.enabled = true;
	}
	public void RevealWolfPup(){
		hideColl.enabled = false;
	}
}
