﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Linq;

public class GameManager : MonoBehaviour {

	private InGameMenu inGameMenuScript;
	public CanvasGroup endPanel;
	public Button restartButton;
	public Text endingText;

	public static GameManager instance;

	public string gameScene;
	public List<string> additiveSceneNames = new List<string>();

	public int killedDucks;
	public Text killedDucksText;
	public bool paused;
	public bool playerCanMove;

	public Transform cameraTr{ get; private set;}
	public Button startButton;
	public CanvasGroup startPanel;

	void Awake(){
		SceneManager.sceneLoaded += SceneLoaded;
		int sceneCount = SceneManager.sceneCount;
		if (sceneCount == 1) {
			LoadScene (gameScene);
		} else {
			additiveSceneNames.Add (gameScene);
		}	
	}
	void Start(){
		instance = this;
		endPanel.alpha = 0;
		inGameMenuScript = GetComponent <InGameMenu> ();

		startPanel.alpha = 1f;
		startButton.Select ();
		cameraTr = Camera.main.transform;	
	}
	void SceneLoaded(Scene loadedScene, LoadSceneMode lsm){
		if (loadedScene.name == gameScene) {
			cameraTr = Camera.main.transform;	
			SceneManager.SetActiveScene (loadedScene);
		}
	}

	void Update(){
		if(Input.GetButtonDown ("Pause")){
			if (!playerCanMove)
				StartGame ();
			else if (endPanel.alpha != 0)
				Restart ();
			else
				SetPausedGame ();
		}
	}

	public void StartGame(){
		playerCanMove = true;
		startPanel.alpha = 0f;
	}

	public void AddScore(){
		killedDucks++;
		killedDucksText.text = "x" + killedDucks;
	}

	public void Restart(){
		Time.timeScale = 1;
		for(int i = 0; i < additiveSceneNames.Count; i ++){
			string sceneName = additiveSceneNames [i];
			UnloadScene (sceneName);
			LoadScene (sceneName);
		}
		endPanel.interactable = false;
		endPanel.alpha = 0f;
		playerCanMove = true;
	}

	public void CallGameEnding(string endingText = "The end"){
		Time.timeScale = 0.5f;
		StartCoroutine (EndGame ());
		endPanel.interactable = true;
		this.endingText.text = endingText;
	}

	public void LoadScene(string sceneName){
		if (!SceneManager.GetSceneByName (sceneName).isLoaded) {
			additiveSceneNames.Add (sceneName);
			SceneManager.LoadScene (sceneName, LoadSceneMode.Additive);
		}
	}

	public void UnloadScene(string sceneName){
		if (SceneManager.GetSceneByName (sceneName).isLoaded) {
			additiveSceneNames.Remove (sceneName);
			SceneManager.UnloadSceneAsync (sceneName);
		}
	}

	public void SetPausedGame(){
		paused = !paused;
		AudioManager.instance.SetPausedPitch (paused);
		inGameMenuScript.ShowPausedMenu (paused);
		Time.timeScale = paused ? 0f : 1f;
	}
		
	IEnumerator EndGame(){
		float t = 0;
		while(t < 1){
			t += Time.deltaTime;
			endPanel.alpha = t;
			yield return 0;
		}
		restartButton.Select ();
		Time.timeScale = 0f;
	}
}
public enum SceneName{
	Basic,FollowTrack,Hunt,Hide,Talk
}
