﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WolfHealth : MonoBehaviour, IWolf {
	public int health = 14;
	public int maxHealth;
	public RectTransform healthBar;
	private Vector2 hbAnchoredPos;
	private int healthBarWidth;
	private int hbHeight;

	void Start () {
		maxHealth = health;
		healthBarWidth = Mathf.RoundToInt (healthBar.sizeDelta.x);
		hbHeight = Mathf.RoundToInt (healthBar.sizeDelta.y);
		InvokeRepeating ("DamageSelf", 5,2.6f);
		hbAnchoredPos = healthBar.anchoredPosition;
	}

	void UpdateHealthBar(){
		float percentage = (float)health / (float)maxHealth;
		healthBar.anchoredPosition = new Vector2 (-healthBarWidth * 0.5f * (1f-percentage) + hbAnchoredPos.x, hbAnchoredPos.y);
		healthBar.sizeDelta = new Vector2 (healthBarWidth * percentage, hbHeight);
	}

	void DamageSelf(){
		Damage (1);
	}

	#region IWolf implementation
	public void Damage (int damage)
	{
		health -= damage;
		if(health <= 0){
			health = 0;
			GameManager.instance.CallGameEnding ("You have died...");
		}
		UpdateHealthBar ();
	}

	public void Heal (int bonusHP)
	{
		if (health < maxHealth) {
			health = Mathf.Min ((health + bonusHP), maxHealth);
			UpdateHealthBar ();
		}
	}
	#endregion
}
