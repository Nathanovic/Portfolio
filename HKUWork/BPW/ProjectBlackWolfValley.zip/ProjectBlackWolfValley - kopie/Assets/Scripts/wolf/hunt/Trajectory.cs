﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Trajectory {
	public Transform trajectoryOrigin;
	public Transform landingIndicator;

	float landingLocationYOffset;
	LayerMask landingLM;
	Vector3 landingPosition;
	float disableTime;

	float confirmationTime;
	Material confirmationMat;
	Color defaultMatColor;
	[HideInInspector]public bool confirmedJump;

	public Trajectory(Transform player){
		trajectoryOrigin = player;
		landingIndicator = player.Find ("LandingIndicator").transform;
		landingIndicator.SetParent (null);

		landingLocationYOffset = 0.15f;
		landingLM = LayerMask.GetMask ("Obstacle", "Ground");
		landingIndicator.gameObject.SetActive (false);
		disableTime = 0.5f;

		confirmationMat = landingIndicator.GetComponentInChildren <SpriteRenderer> ().material;
		defaultMatColor = confirmationMat.color;
		confirmationTime = 0.5f;
	}

	public IEnumerator EnableTrajectory(){
		landingIndicator.gameObject.SetActive (true);
		confirmedJump = false;
		float fadeTime = confirmationTime / 2;
		Color confColor = defaultMatColor;
		float t = 0f;
		while(landingIndicator.gameObject.activeInHierarchy && t < 1f){
			t += Time.deltaTime / fadeTime;
			confColor.a = Mathf.Lerp (0.5f,1f,t);
			confirmationMat.color = confColor;
			yield return 0;
		}
		while(landingIndicator.gameObject.activeInHierarchy && t > 0f){
			t -= Time.deltaTime / fadeTime;
			confColor.a = Mathf.Lerp (0.5f,1f,t);
			confirmationMat.color = confColor;
			yield return 0;
		}
		confirmationMat.color = defaultMatColor;
		confirmedJump = true;
	}

	public IEnumerator DisableTrajectory(){
		yield return new WaitForSeconds (disableTime);
		landingIndicator.gameObject.SetActive (false);		
	}
	public void PlotIt(Vector3 jumpDir, float shootForce){
		PlotTrajectory (trajectoryOrigin.position, shootForce * jumpDir, 0.2f, 3f, out landingPosition);
		ShowLandingLocation (landingPosition);
	}

	void ShowLandingLocation(Vector3 newLoc){
		if(newLoc != Vector3.down){
			newLoc.y += landingLocationYOffset;
			landingIndicator.position = newLoc;
		}
	}

	Vector3 PlotTrajectoryAtTime (Vector3 start, Vector3 startVelocity, float time) {
		return start + startVelocity*time + Physics.gravity*time*time*0.5f;
	}
	void PlotTrajectory (Vector3 start, Vector3 startVelocity, float timestep, float maxTime, out Vector3 hitLocation) {
		Vector3 prev = start;
		for (int i=1;;i++) {
			float t = timestep*i;
			if (t > maxTime) {
				hitLocation = Vector3.down;
				break;
			}
			Vector3 pos = PlotTrajectoryAtTime (start, startVelocity, t);
			RaycastHit hit;
			if (Physics.Linecast (prev, pos, out hit, landingLM)) {
				hitLocation = hit.point;
				break;
			}
			//Debug.DrawLine (prev,pos,Color.red);
			prev = pos;
		}
	}
}
