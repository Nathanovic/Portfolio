﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IHealable<T>{
	void Heal(T bonusHP);
}
public interface IDamagable<T>{
	void Damage(T damage);
}

public interface IWolf : IHealable<int>,IDamagable<int>{}
