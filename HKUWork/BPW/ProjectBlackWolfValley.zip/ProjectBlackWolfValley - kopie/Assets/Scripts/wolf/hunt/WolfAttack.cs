﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(WolfMovement))]
[RequireComponent(typeof(WolfStateHandler))]
public class WolfAttack : MonoBehaviour {

	private WolfMovement moveScript;
	private WolfStateHandler stateScript;
	private IZoomable cameraZoomer;
	private Rigidbody rb;
	private Trajectory trajectoryHandler;

	public JumpState jumpState;
	public Vector3 jumpDir = new Vector3(0,1,2);
	public float jumpPrepareTime = 1.5f;

	public float jumpForce = 6f;
	public float maxJumpForce = 10f;
	public float minJumpForce = 6f;
	public float deltaJumpForce;

	public AudioClip jumpAudio;

	void Start () {
		moveScript = GetComponent <WolfMovement> ();
		stateScript = GetComponent <WolfStateHandler> ();
		cameraZoomer = Camera.main.GetComponent <IZoomable> ();
		rb = GetComponent <Rigidbody> ();
		trajectoryHandler = new Trajectory (transform);

		jumpDir.Normalize ();
		jumpForce = minJumpForce;
		deltaJumpForce = maxJumpForce - minJumpForce;

		stateScript.ReleaseJumpAttackButtonEvent += ReleaseJumpButton;
	}

	void Update () {
		if(stateScript.jumpAttackButtonDown && !GameManager.instance.paused){
			if (jumpState == JumpState.none && !cameraZoomer.isInLerpControl) {
				jumpState = JumpState.confirm;
				trajectoryHandler.PlotIt (JumpForceVector(), jumpForce);
				StartCoroutine(trajectoryHandler.EnableTrajectory ());
			}
			if (trajectoryHandler.confirmedJump && jumpState == JumpState.confirm) {
				cameraZoomer.DisableCameraControl ();
				jumpState = JumpState.prepare;
			}
		}

		if (jumpState == JumpState.prepare) {
			moveScript.JumpRotateMe (0.06f);

			jumpForce += deltaJumpForce * Time.deltaTime / jumpPrepareTime;
			if (jumpForce >= maxJumpForce)
				ReleaseJumpButton ();
			else
				trajectoryHandler.PlotIt (JumpForceVector (), jumpForce);
		}
	}

	Vector3 JumpForceVector(){
		return transform.TransformDirection (jumpDir);
	}
	void ReleaseJumpButton(){
		if (jumpState == JumpState.prepare || jumpState == JumpState.confirm) {
			if (jumpState == JumpState.prepare) {
				rb.AddForce (JumpForceVector () * jumpForce, ForceMode.Impulse);
				jumpState = JumpState.jumping;
				jumpForce = minJumpForce;
				AudioManager.instance.PlayAudioClip (jumpAudio);
			} else
				jumpState = JumpState.none;
			
			StartCoroutine (trajectoryHandler.DisableTrajectory ());
		}
	}
		
	void JumpEnding(){
		Invoke ("EnableMovement", 0.6f);
		jumpState = JumpState.none;
	}
	void EnableMovement(){
		Vector3 normalRotation = transform.rotation.eulerAngles;
		normalRotation.x = normalRotation.z = 0;
		transform.rotation = Quaternion.Euler (normalRotation); 	
		cameraZoomer.ZoomToDefaultPos ();
	}

	void OnTriggerEnter(Collider other){
		if(other.tag == "Prey" && jumpState == JumpState.jumping){
			Bird birdScript = other.GetComponent <Bird> ();
			birdScript.CaughtMe ();
		}
	}
	void OnCollisionEnter(Collision coll){
		if(coll.collider.tag == "Ground" && jumpState == JumpState.jumping){
			JumpEnding ();
		}
	}

	public enum JumpState{
		none,confirm,prepare,jumping
	}
}
