﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WolfEat : MonoBehaviour {
	public CanvasGroup pressAFeedbackPanel;
	private Animator pressAFeedbackAnim;
	private Image pressACircle;

	private IEateable eatablePrey;
	private Collider preyColl;
	private bool _isEating;
	public bool isEating{
		get{ 
			return _isEating;
		}
		set{ 
			_isEating = value;
		}
	}
		
	public float eatWaitTime = 1.5f;
	private float lastEatingMoment = -10f;
	private float eatCD{
		get{ 
			return Time.time - lastEatingMoment;
		}
	}
	public float eatOneFoodTime = 2;

	private WolfHealth healthScript;
	private WolfStateHandler stateScript;

	public float eatDistance = 1.2f;
	public float eatMoveSpeed = 2f;

	void Start(){
		pressAFeedbackAnim = pressAFeedbackPanel.GetComponent <Animator> ();
		pressACircle = pressAFeedbackPanel.GetComponent <Image> ();
		healthScript = transform.parent.GetComponent <WolfHealth> ();
		stateScript = transform.parent.GetComponent <WolfStateHandler> ();
	}

	void Update(){
		if(Input.GetButtonDown ("X") && preyColl != null && !isEating){
			isEating = true;
		}
		else if (Input.GetButtonUp ("X") && isEating && eatCD >= eatWaitTime) {
			Eat ();
		}
		if(isEating){
			if (stateScript.inputMagnitude == 0f) {
				MoveToEatPosition ();
			} else {
				isEating = false;
			}
		}
	}

	void OnTriggerEnter(Collider coll){
		if(preyColl == null && coll.tag == "Eateable"){
			preyColl = coll;
			eatablePrey = coll.transform.parent.GetComponent <IEateable> ();
			eatablePrey.EnableEatFromMe ();
			pressAFeedbackAnim.SetBool ("active", true);
			ShowRemainingFood ();

			NotificationView.instance.ShowNotification ("Press X to eat");
		}
	}
	void OnTriggerExit(Collider coll){
		if(coll == preyColl){
			ResetPrey ();
		}
	}

	void Eat(){
		lastEatingMoment = Time.time;
		eatablePrey.EatFromMe ();
		healthScript.Heal (3);

		ShowRemainingFood ();
		if(eatablePrey.RemainingFood == 0){
			ResetPrey ();
		}
	}
	void MoveToEatPosition(){
		Vector3 targetPos = preyColl.transform.position;
		targetPos.y = transform.parent.position.y;
		Vector3 lookDir = targetPos - transform.parent.position;
		transform.parent.rotation = Quaternion.LookRotation (lookDir);

		targetPos -= lookDir.normalized * eatDistance;
		Vector3 newParentPos = Vector3.MoveTowards (transform.parent.position, targetPos, eatMoveSpeed * Time.deltaTime);
		transform.parent.position = newParentPos;
	}

	void ShowRemainingFood(){
		float percentage = (float)eatablePrey.RemainingFood / (float)eatablePrey.FoodAmount;
		pressACircle.fillAmount = percentage;		
	}

	void ResetPrey(){
		preyColl = null;	
		eatablePrey = null;
		isEating = false;
		pressAFeedbackAnim.SetBool ("active", false);
	}
}
