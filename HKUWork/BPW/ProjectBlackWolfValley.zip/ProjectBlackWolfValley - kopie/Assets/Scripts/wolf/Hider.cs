﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(WolfMovement))]
[RequireComponent(typeof(WolfStateHandler))]
public class Hider : MonoBehaviour {
	private WolfStateHandler focusScript;

	public List<Collider> currentHidingColls = new List<Collider>();
	public List<HidingPlace> currentHidingPlaces = new List<HidingPlace>();
	public List<Renderer> currentRenderers = new List<Renderer> ();

	public Material standardBushesMat;
	public Material semiTranspBushesMat;

	void Start(){
		focusScript = GetComponent <WolfStateHandler> ();
		focusScript.SetFocusButtonEvent += RevealWolfPup;
	}

	void OnTriggerStay(Collider coll){
		if(coll.tag == "HidingPlace" && !currentHidingColls.Contains (coll) && focusScript.focusButtonDown) {
			HideInBushes (coll);
		}
	}
	void OnTriggerExit(Collider coll){
		if(currentHidingColls.Contains (coll)){
			LeaveBushes (coll);
		}
	}

	void RevealWolfPup(bool buttonDown){
		if (!buttonDown) {
			foreach (HidingPlace hidingPlace in currentHidingPlaces) {
				hidingPlace.RevealWolfPup ();
			}
			foreach (Renderer r in currentRenderers) {
				r.material = standardBushesMat;
			}
			currentHidingColls.Clear ();
			currentRenderers.Clear ();
			currentHidingPlaces.Clear ();
		}
	}

	void HideInBushes(Collider touchedColl){
		Transform bushesTr = touchedColl.transform.parent;
		Renderer touchedR = bushesTr.GetComponent <Renderer> ();
		HidingPlace hidingPlaceScript = bushesTr.GetComponent <HidingPlace> ();

		touchedR.material = semiTranspBushesMat;
		hidingPlaceScript.HideWolfPup ();

		currentHidingColls.Add (touchedColl);
		currentRenderers.Add (touchedR);
		currentHidingPlaces.Add (hidingPlaceScript);
	}
	void LeaveBushes(Collider touchedColl){
		Transform bushesTr = touchedColl.transform.parent;
		Renderer touchedR = bushesTr.GetComponent <Renderer> ();
		HidingPlace hidingPlaceScript = bushesTr.GetComponent <HidingPlace> ();

		touchedR.material = standardBushesMat;
		hidingPlaceScript.RevealWolfPup ();

		currentHidingColls.Remove (touchedColl);
		currentHidingPlaces.Remove (hidingPlaceScript);
		currentRenderers.Remove (touchedR);
	}
}
