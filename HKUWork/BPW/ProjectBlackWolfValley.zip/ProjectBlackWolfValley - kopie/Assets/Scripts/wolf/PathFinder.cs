﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathFinder : MonoBehaviour {
	Track currentTrack;
	public List<Collider> collidingTracks = new List<Collider>();
	private float leaveTrackMoment;
	public float showTrackNotificationTimeThreshold = 5f;

	public bool isFocused = false;

	void Start(){
		leaveTrackMoment = -showTrackNotificationTimeThreshold;
	}
	 
	void OnTriggerEnter(Collider other){
		if (other.tag == "Track") {
			if (collidingTracks.Count == 1 && collidingTracks [0] == other) {
				NewTrack (other.transform);
			}
		}
	}
	void OnTriggerStay(Collider other){
		if(other.tag == "Track"){	
			if(collidingTracks.Count == 0 || (isFocused && !collidingTracks.Contains (other))){
				if (collidingTracks.Count == 0)
					NewTrack (other.transform);

				collidingTracks.Add (other);
				currentTrack.ShowTrackPart (other.gameObject);
			}
		}
	}
	void OnTriggerExit(Collider other){
		if (other.tag == "Track" && collidingTracks.Contains (other)) {
			if (collidingTracks.Count == 1)
				LeaveTrack ();
			else {
				if (collidingTracks [0] != other) {
					collidingTracks.Remove (other);
					currentTrack.HideTrackPart (other.gameObject);
				}
			}
		}
	}

	void NewTrack(Transform trackPart){
		NotificationView.instance.ShowNotification ("Hold RT = focus mode");
		currentTrack = trackPart.root.GetComponent <Track> ();
		if((Time.time - leaveTrackMoment) > showTrackNotificationTimeThreshold){
			currentTrack.ShowTrackNotification (trackPart.position);	
		}
	}
	void LeaveTrack(){
		leaveTrackMoment = Time.time;
	}
}
