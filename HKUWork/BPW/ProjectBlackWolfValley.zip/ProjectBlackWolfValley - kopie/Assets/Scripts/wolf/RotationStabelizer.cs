﻿using System.Collections;
using UnityEngine;

public class RotationStabelizer : MonoBehaviour {
	public float minimumX = -18F;
	public float maximumX = 18F;
	private Rigidbody rb;
	public float xVelReducer = 0.95f;

	void Start(){
		rb = GetComponent <Rigidbody> ();
	}

	void Update () {
		Vector3 myEuler = transform.eulerAngles;
		if (myEuler.x > maximumX || myEuler.x < minimumX) {
			transform.rotation = ClampRotationAroundXAxis (transform.rotation);
			Vector3 angularVel = rb.angularVelocity;
			angularVel.x *= xVelReducer;
			rb.angularVelocity = angularVel;
		}
	}

	Quaternion ClampRotationAroundXAxis(Quaternion q)
	{
		q.x /= q.w;
		q.y /= q.w;
		q.z /= q.w;
		q.w = 1.0f;

		float angleX = 2.0f * Mathf.Rad2Deg * Mathf.Atan (q.x);

		angleX = Mathf.Clamp (angleX, minimumX, maximumX);

		q.x = Mathf.Tan (0.5f * Mathf.Deg2Rad * angleX);

		return q;
	}
}
