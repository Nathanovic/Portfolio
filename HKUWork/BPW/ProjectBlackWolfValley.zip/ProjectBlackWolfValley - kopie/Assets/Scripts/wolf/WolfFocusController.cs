﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(WolfStateHandler))]
[RequireComponent(typeof(PathFinder))]
[RequireComponent(typeof(WolfMovement))]
public class WolfFocusController : MonoBehaviour {
	WolfStateHandler stateScript;
	PathFinder pathfinderScript;
	IZoomable cameraZoomer;

	void Start () {
		cameraZoomer = Camera.main.GetComponent <IZoomable> ();
		stateScript = GetComponent <WolfStateHandler> ();
		pathfinderScript = GetComponent <PathFinder> ();

		stateScript.SetFocusButtonEvent += StopFocusing;
	}
	
	void Update () {
		if(stateScript.focusButtonDown && !pathfinderScript.isFocused)
			FocusMode ();
	}

	void FocusMode(){
		bool reachedFocusPosition = false;
		cameraZoomer.ZoomCamera (3f, out reachedFocusPosition);

		if (reachedFocusPosition) {
			stateScript.activityState = ActivityState.sneak;
			pathfinderScript.isFocused = true;
			NotificationView.instance.ShowNotification ("Focus mode enabled!");
		}			
	}
	void StopFocusing(bool buttonDown){
		if (!buttonDown) {
			cameraZoomer.ZoomToDefaultPos ();
			pathfinderScript.isFocused = false;
			if(stateScript.activityState == ActivityState.sneak)
				stateScript.activityState = ActivityState.standard;
		}
	}
}
