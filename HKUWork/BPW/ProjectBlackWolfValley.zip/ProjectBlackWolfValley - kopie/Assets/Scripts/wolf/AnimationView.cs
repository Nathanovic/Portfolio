﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(WolfStateHandler))]
public class AnimationView : MonoBehaviour {
	private WolfStateHandler stateScript;
	private Animator anim;

	void Start () {
		anim = GetComponent <Animator> ();
		stateScript = GetComponent <WolfStateHandler> ();
	}

	void Update () {
		anim.SetFloat ("inputMagnitude", stateScript.inputMagnitude);		
		anim.SetInteger ("activity", (int)stateScript.activityState);

		if (stateScript.moveState == MoveState.run) 
			anim.SetBool ("run", true);
		else
			anim.SetBool ("run", false);
	}
}
