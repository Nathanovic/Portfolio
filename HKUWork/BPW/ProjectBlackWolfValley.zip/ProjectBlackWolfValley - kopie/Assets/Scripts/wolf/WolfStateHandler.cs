﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//receives all useful input (behalve WolfAttack3.cs (luiheid))
public class WolfStateHandler : MonoBehaviour {
	public ActivityState activityState;//set by wolffocuscontroller script and wolfattack script
	public MoveState moveState;

	private Transform camTr;
	public float inputDeadValue = 0.2f;
	public Vector3 inputDirection;
	public float inputMagnitude;

	public bool focusButtonDown;
	public bool jumpAttackButtonDown;

	public delegate void ButtonDelegate(bool buttonDown);
	public event ButtonDelegate SetFocusButtonEvent;
	public delegate void ButtonDownDelegate();
	public event ButtonDownDelegate ReleaseJumpAttackButtonEvent;

	void Start () {
		camTr = Camera.main.transform.GetChild (0);
		SetFocusButtonEvent += SetFocusButtonDown;
		ReleaseJumpAttackButtonEvent += ReleaseJumpAttackButton;
	}

	void Update () {
		inputDirection = GameManager.instance.playerCanMove ? InputDirection () : Vector3.zero;
		inputMagnitude = inputDirection.magnitude;

		if (!focusButtonDown && Input.GetAxis ("TriggerAxis") < 0f)
			SetFocusButtonEvent (true);
		else if (focusButtonDown && Input.GetAxis ("TriggerAxis") >= 0f)
			SetFocusButtonEvent (false);

		if (Input.GetButtonDown ("JumpAttack") && GameManager.instance.playerCanMove)
			jumpAttackButtonDown = true;
		else if(Input.GetButtonUp ("JumpAttack"))
			ReleaseJumpAttackButtonEvent ();

		if (inputMagnitude == 0) {
			moveState = MoveState.idle;
		} else if (IsRunning ()) {
			moveState = MoveState.run;
		} else {
			moveState = MoveState.walk;
		}
	}

	Vector3 InputDirection(){
		float inputX = Input.GetAxisRaw ("Horizontal");
		float inputZ = Input.GetAxisRaw ("Vertical");
		Vector3 inputDir = new Vector3 (inputX, 0, inputZ);
		if (inputDir.magnitude > inputDeadValue){
			inputDir = camTr.TransformDirection (inputDir);
			return inputDir;
		}else{
			return Vector3.zero;
		}
	}

	bool IsRunning(){
		if (!focusButtonDown && Input.GetAxis ("TriggerAxis") > 0f && inputMagnitude > 0.4f) {
			return true;
		} else {
			return false;
		}
	}

	void SetFocusButtonDown(bool buttonDown){
		focusButtonDown = buttonDown;
	}
	void ReleaseJumpAttackButton(){
		jumpAttackButtonDown = false;
	}
}

public enum MoveState{
	idle,walk,run
}
public enum ActivityState{
	standard,sneak,jump
}