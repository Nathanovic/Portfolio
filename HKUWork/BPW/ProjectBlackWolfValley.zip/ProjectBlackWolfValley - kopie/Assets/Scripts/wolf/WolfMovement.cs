﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(WolfStateHandler))]
public class WolfMovement : MonoBehaviour {
	private WolfStateHandler stateScript;

	public float moveSpeed = 5;
	public float focusedSpeedMultiplier = 0.7f;
	public float runSpeedMultiplier = 2.3f;
	public float jumpSpeed = 30;
	public float maxAngle = 40f;

	private IZoomable cameraZoomer;
	private bool playerControlsCamera{
		get{ 
			return !cameraZoomer.isInLerpControl;
		}
	}

	[Header("Debug:")]
	public float rotateSpeed = 8f;
	public Transform nosecheckObj;
	public LayerMask noseLM;
	public float noseCheckRayLength = 0.7f;

	void Start(){
		stateScript = GetComponent <WolfStateHandler> ();
		cameraZoomer = Camera.main.GetComponent <IZoomable> ();
		Physics.gravity = new Vector3 (0,-12.5f,0);
		noseLM = LayerMask.GetMask ("Ground", "Obstacle");
	}

	void Update () {
		float currentSpeed = ForwardSpeed (stateScript.inputMagnitude);

		if (currentSpeed > 0f){
			Vector3 movement = stateScript.inputDirection * currentSpeed;
			RotateMe (movement);
			bool canMoveFwd = CanMoveForward ();
			if(canMoveFwd)
				MoveMe (currentSpeed);
		}
	}

	void FixedUpdate(){
		Vector3 normalRot = transform.rotation.eulerAngles;
		normalRot.z = 0f;
		transform.rotation = Quaternion.Euler (normalRot);
	}
		
	public void JumpRotateMe(float rotMultiplier){
		if(stateScript.inputMagnitude > 0f){
			RotateMe (stateScript.inputDirection, rotMultiplier);
		}
	}
	void RotateMe(Vector3 walkDir, float rotMultiplier = 1f){
		Vector3 newDir = Vector3.RotateTowards (transform.forward, walkDir,rotateSpeed * Time.deltaTime * rotMultiplier, 0f); //use for lerping rotation
		Vector3 lookRot = Quaternion.LookRotation (newDir).eulerAngles;
		lookRot.z = 0f;
		float x = transform.rotation.eulerAngles.x;
		if (x <= 180f && x > maxAngle)
			lookRot.x = maxAngle;
		else if (x <= -180f && x > -maxAngle)
			lookRot.x = -maxAngle;			
		else
			lookRot.x = x;
		transform.rotation = Quaternion.Euler (lookRot);
	}
	bool CanMoveForward(){
		RaycastHit hit;
		if (Physics.Raycast (nosecheckObj.position, nosecheckObj.forward, out hit, noseCheckRayLength, noseLM)) {
			if (!hit.collider.isTrigger) {
				return false;
			} else {
				print (hit.collider.name);
			}
		}
		return true;
	}
	float ForwardSpeed(float inputMagn){
		float forwardSpeed = inputMagn * moveSpeed;
		if (stateScript.jumpAttackButtonDown)
			forwardSpeed = 0f;
		else if (stateScript.focusButtonDown)
			forwardSpeed *= focusedSpeedMultiplier;
		else if (stateScript.moveState == MoveState.run)
			forwardSpeed *= runSpeedMultiplier;
		return forwardSpeed;
	}
	void MoveMe(float moveSpeed){		
		transform.Translate (transform.forward * Time.deltaTime * moveSpeed, Space.World);		
  	}
}
