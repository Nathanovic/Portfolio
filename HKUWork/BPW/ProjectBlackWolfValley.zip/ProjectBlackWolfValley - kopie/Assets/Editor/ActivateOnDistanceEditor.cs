﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(HideArea))]
public class ActivateOnDistanceEditor : Editor {

	void OnSceneGUI(){
		HideArea activatorScript = (HideArea)target;
		Vector3 areaOrigin = activatorScript.transform.position;
		Vector3 playerPosition = activatorScript.target.position;
		Handles.color = Color.green;
		Handles.DrawWireArc (areaOrigin, Vector3.up, Vector3.forward, 360f, activatorScript.activationDistance);
		if(activatorScript.active){
			Handles.color = Color.red;
			Handles.DrawLine (areaOrigin, playerPosition);
		}
		foreach(Transform t in activatorScript.distanceDependableTransforms){
			Handles.color = Color.green;
			Handles.DrawDottedLine (areaOrigin, t.position, 2f);
		}
	}
}
